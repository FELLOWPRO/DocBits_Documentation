# Persönliche Freigabe und Wiederholung – tatsächlicher Nachweis

Die beiden persönlichen Entscheidungen gehören zum eigenen separaten Trainingsdokumenttyp.
Sie sind nicht die abschließende B-Entscheidung der älteren abgebildeten PO-Rechnung.
A verwendete das normale OAuth-Testkonto, B das tatsächliche eigene API-Testkonto.
Keine Identitätsübernahme, kein erzwungener Status und keine erfundene UI-Betätigung.
Die native Feldansicht des eigenen Dokumenttyps blieb leer; deshalb ist dies ein
fachlicher API-Nachweis und kein vollständiger nativer Klickablauf.

Nach A entstand die offene B-Aufgabe. Nach der persönlichen B-Entscheidung enthielt
die gespeicherte Reihenfolge A und B; der Status war exported. Wegen des bereits
vorhandenen erfolgreichen Zielmarkers erfolgte keine weitere HTTP-Zustellung.
Zwei spätere getrennte Rückkehrereignisse verwendeten dieselbe offene A-Aufgabe.
A lehnte anschließend tatsächlich ab: rejected, keine offene/neue B-Aufgabe,
kein Exportempfang. Geschäftsfelder und Tabellen blieben unverändert.

Die drei Empfängerfehlerfälle des anderen Archivs sind weiterhin Simulationen.
Alle konkreten Testkonto-, Dokument-, Organisations- und Laufkennungen bleiben privat.
