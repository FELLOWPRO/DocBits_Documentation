# Tatsächliche Run-Workflow-Nachweise, 22.10.2026

Drei ausgewählte Aufrufe eines eigenen inaktiven Aufrufers und eines eigenen inaktiven Ziels auf demselben synthetischen Trainingsbeleg. Die native Zielauswahl wurde gespeichert; anschließend wurden die Zielreferenz und die vom Speichern gebundene eigene Aufruferkennung gelesen. Keine erfundenen versteckten IDs.

case-results.json enthält die beobachteten Resultate. Für jeden Fall wurde die wf_run_id aus dem Aufrufkartenlog mit der primären id des tatsächlich veröffentlichten Zielprotokolls abgeglichen. Das gesonderte run_id-Feld des Protokolls war leer und wurde nicht als Zuordnung verwendet. Rohdaten der Organisation und Zugangsdaten sind nicht enthalten.

positive ist ein Gegenbeispiel für eine angenommene sofortige Datenweitergabe: Der Zielvergleich war erfolgreich, das Ziel speicherte WF-TRAINING-CHILD-OK als Rechnungsnummer, der direkte Folgevergleich des Aufrufers las jedoch noch wf-training-001. Die im Aufrufer danach angeordnete Rückstellung wurde nicht erreicht. Anschließend wurde ausschließlich die eigene Rechnungsnummer über den normalen Dokument-Update-Endpunkt zurückgestellt und der übrige Geschäftszustand verglichen. Der ursprüngliche Lauf wurde nicht wiederholt.

target-false verwendete die Vergleichsgrenze2000 bei einem Betrag1785: Zielbedingung falsch, Aufrufkarte trotzdem erfolgreich, keine Markeraktion. target-error verwendete den ungültigen Vergleichsparameterabc: Zielfehler und Aufruffehler, keine Folgeaktionen. Die reguläre Zielkonfiguration wurde nach den Proben wieder auf1000 gestellt; beide Regeln blieben inaktiv.

Dieser Aufbau dient dem Nachweis des Dokumentkontexts. Er ist kein produktiver Ablauf zum Ändern einer Rechnungsnummer und kein zugesicherter Ausgabevertrag für Folgekarten. Fachlich zusammenhängende Aktionen müssen im tatsächlich geprüften Kontext liegen; gespeicherte Werte sind in einem frischen Kontext erneut zu lesen.
