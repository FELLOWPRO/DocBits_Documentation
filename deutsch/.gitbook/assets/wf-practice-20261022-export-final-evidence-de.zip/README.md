# Tatsächlich ausgeführter verzögerter Abschluss-Export

Ein normaler Statusanlass für den eigenen Trainingsbeleg erreichte die verzögerte
Exportkarte v3 mit der eigenen Konfiguration und Abschlussstatus finished.
Der finale Export lieferte genau einen neuen HTTP200-Empfang: WF-EXPORT-20261022-002.
Zusammen mit dem historischen unmittelbaren Export sind zwei Empfängereinträge vorhanden.
duplicate_document=true ist die Beobachtung des Testempfängers, keine automatische
DocBits-Deduplizierung. Der Testempfänger führt keine Buchung und keine Zahlung aus.

Der Beleg wurde finished. Ein zusätzlicher statusbedingter Folgelauf stoppte am
falschen Ausgangsstatus; keine dritte Zustellung. Geschäftsfelder und Tabellen
blieben unverändert. Eigene Regel und Konfiguration wurden deaktiviert, temporärer
Empfänger und Tunnel beendet. Der alternative Export wurde nicht ausgeführt.
Die unveränderten historischen Vier-Fälle-Nachweise bleiben in ihrem eigenen Archiv.
