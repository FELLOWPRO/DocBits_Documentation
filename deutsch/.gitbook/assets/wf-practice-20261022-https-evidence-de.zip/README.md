# Tatsächliche HTTPS-Praxisnachweise, 22.10.2026

Fünf bewusst ausgewählte Läufe eines eigenen inaktiven Trainingsworkflows an einem eigenen temporären Empfänger. Ausschließlich statische synthetische request_id-Werte, cost_center=4711 und total_amount=1785. Kein Callback-Kontext, keine produktiven Zugangsdaten, keine Buchung.

actual-receipts.jsonl ist die unveränderte Empfängerdatei. Jeder Lauf erzeugte zuerst Formulardaten mit JSON-Header, erhielt HTTP400 mit „input must be a valid json object“ und wurde von der Karte automatisch als JSON wiederholt. response_status/response_body protokollieren die vom Empfänger gewählte Antwort, keine Bestätigung, dass der Aufrufer sie verarbeitet hat. Beim slow-Fall wurde die geplante Antwort erst nach65 Sekunden versucht; die Karte brach laut gespeichertem Lauf nach60 Sekunden mit ReadTimeout ab. Der Request war trotzdem angekommen. ok-repeat wurde durch das Testziel als Duplikat erkannt; daraus folgt keine automatische DocBits-Deduplizierung.

cases.csv fasst die tatsächlichen Kartenlogs zusammen. success=true des ausgewählten Ausführungsendpunkts war bei fail kein Beleg für eine erfolgreiche HTTPS-Karte. Ungültiges Antwort-JSON bei HTTP200 blieb in dieser Kartenfassung erfolgreich. In keinem der fünf Fälle wurden Geschäftsfelder, Tabellen oder Status des eigenen Belegs verändert; ein Feld cost_center wurde nicht angelegt.

receiver.py enthält den temporären lokalen Empfänger der Übung. Für eine Wiederholung sind ein eigenes erreichbares HTTPS-Ziel und neu gewählte synthetische Versuchsdaten erforderlich. Die Screenshot-Testadresse wird nach der Aufnahme abgeschaltet.
