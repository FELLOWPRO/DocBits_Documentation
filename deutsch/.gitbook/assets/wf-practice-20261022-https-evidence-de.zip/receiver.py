"""Temporary receiver for synthetic WF documentation requests only."""
import datetime
import html
import json
import signal
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, parse_qs

ROOT = Path(__file__).parent
PREFIX = '/wf-training-20261022-7c68d1'
PORT = 57682
RECEIPTS = ROOT / 'actual-receipts.jsonl'
LOCK = threading.Lock()
ACCEPTED = set()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def send(self, status, body, content_type='application/json'):
        body = body.encode()
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_GET(self):
        if self.path == PREFIX + '/health':
            self.send(200, '{"receiver":"WF documentation synthetic test","ready":true}')
        elif self.path == '/review' and self.headers.get('Host', '').split(':')[0] in ['127.0.0.1', 'localhost']:
            rows = [json.loads(x) for x in RECEIPTS.read_text().splitlines()] if RECEIPTS.exists() else []
            blocks = ''.join('<article><h2>Empfang ' + str(i+1) + '</h2><pre>' + html.escape(json.dumps(row, ensure_ascii=False, indent=2)) + '</pre></article>' for i, row in enumerate(rows))
            self.send(200, '<!doctype html><meta charset="utf-8"><title>WF-Testziel: tatsächlicher Empfang</title><style>body{font:16px system-ui;max-width:1020px;margin:28px auto;color:#163746;background:#f6fafb}h1{font-size:27px}article{background:white;border:1px solid #c8dce3;padding:18px;margin:18px 0;border-radius:8px}h2{font-size:18px;margin:0 0 12px}pre{font:15px ui-monospace,monospace;white-space:pre-wrap;margin:0;line-height:1.5}</style><h1>WF-Testziel: tatsächlicher Empfang</h1><p>Eigener temporärer Empfänger · ausschließlich synthetische Daten · keine Buchung</p>' + (blocks or '<p>Noch kein Request empfangen.</p>'), 'text/html; charset=utf-8')
        else:
            self.send(404, '{"error":"not found"}')

    def do_POST(self):
        path = urlsplit(self.path).path
        if path not in [PREFIX + '/' + x for x in ['ok', 'fail', 'invalid-json', 'slow']]:
            self.send(404, '{"error":"not found"}')
            return
        size = int(self.headers.get('Content-Length', '0'))
        if not 0 < size <= 4096:
            self.send(413, '{"error":"body size"}')
            return
        body = self.rfile.read(size).decode('utf-8', errors='replace')
        request_id = None
        parsed = None
        try:
            parsed = json.loads(body)
            request_id = parsed.get('request_id') if isinstance(parsed, dict) else None
        except ValueError:
            pass
        form = parse_qs(body)
        if parsed is None and form:
            request_id = (form.get('request_id') or [None])[0]
        if not isinstance(request_id, str) or not request_id.startswith('WF-DOCS-20261022-'):
            self.send(400, '{"error":"synthetic request_id required"}')
            return
        if parsed is None:
            status, response = 400, '{"error":"input must be a valid json object"}'
        elif set(parsed) != {'request_id', 'cost_center', 'total_amount'} or parsed['cost_center'] != '4711' or str(parsed['total_amount']) != '1785':
            self.send(400, '{"error":"only fixed synthetic fixture accepted"}')
            return
        elif path.endswith('/fail'):
            status, response = 503, '{"accepted":false,"reason":"planned test failure"}'
        elif path.endswith('/invalid-json'):
            status, response = 200, 'WF_TEST_INVALID_JSON'
        elif path.endswith('/slow'):
            status, response = 200, '{"accepted":true,"delay_seconds":65}'
        else:
            with LOCK:
                duplicate = request_id in ACCEPTED
                ACCEPTED.add(request_id)
            status, response = 200, json.dumps({'accepted': True, 'cost_center': '4711', 'duplicate': duplicate}, separators=(',', ':'))
        receipt = {'received_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'method': 'POST', 'path': path, 'content_type': self.headers.get('Content-Type'), 'demo_header': self.headers.get('X-WF-Demo'), 'body_bytes_utf8': body, 'response_status': status, 'response_body': response}
        with LOCK:
            with RECEIPTS.open('a') as stream:
                stream.write(json.dumps(receipt, ensure_ascii=False) + '\n')
        if path.endswith('/slow') and parsed is not None:
            time.sleep(65)
        self.send(status, response)


server = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
server.daemon_threads = True
def stop(*_args):
    threading.Thread(target=server.shutdown, daemon=True).start()
signal.signal(signal.SIGTERM, stop)
signal.signal(signal.SIGINT, stop)
expiry = threading.Timer(2 * 60 * 60, stop)
expiry.daemon = True
expiry.start()
print(json.dumps({'receiver_pid': __import__('os').getpid(), 'port': PORT, 'prefix': PREFIX, 'expires_after_seconds': 7200}), flush=True)
server.serve_forever()
server.server_close()
expiry.cancel()
