# Settings assistant explainer videos — local pilot

This offline production package builds only `layouts × en/de/ja/hu`. Rendering is offline. Publishing is a separate explicit command; neither command
accesses organization data or authorizes bulk rendering. MP4/VTT/PNG, provenance and candidate manifests stay in ignored `out/`;
original speech and alignment stay in ignored `cache/tts/`. Both API branches use
identical source files and the same local media inventory.

## Frozen environment

Python 3.11.11, Manim Community 0.19.0/Cairo, FFmpeg and ffprobe 7.1.1; arm64 Linux.
`requirements.lock` pins transitive package versions and distribution hashes.
`toolchain.lock.json` records the measured immutable local image ID, installed
Python packages, OS package inventory digest, Cairo/Pango/HarfBuzz/libx264 and
FFmpeg build identities. Rendering fails on environment or font drift. Rebuilding
the Dockerfile is a provisioning operation: it must match the recorded environment
before it is usable. Preserve the measured local image for exact rebuilds; it has
not been pushed to any registry.

`fonts.lock.json` pins commit URLs and hashes for Noto Sans, native JP/SC/KR/Thai
faces and mathematical/symbol fallbacks. OFL licenses are included. Fontconfig
uses only the package cache. The logo is the supplied `promo/brand/logo_white.png`,
verified against `brand.lock.json`, and is kept in `cache/brand/`, not Git. The
palette and panel/grid treatment reuse the supplied promo scene. A fresh checkout
must receive that exact logo and the retained TTS cache from the local build
archive; no replacement voice synthesis happens implicitly.

From the repository root:

```sh
docker build -t core6274-video scripts/settings_assistant/explainer_videos
docker run --rm -v "$PWD":/repo core6274-video python toolchain.py
```

A new machine can fetch the checksum-pinned fonts with `toolchain.install_fonts()`.
The release build itself does not fetch fonts. Do not overwrite a reviewed lock
with `toolchain.py --freeze-image` merely to bypass an environment failure.

## Speech acquisition — explicit network action

Only this command may submit paid TTS requests. It mounts the designated dotenv
file read-only and never prints its secret. Request IDs are persisted for resume;
a cache hit validates original MP3, decoded WAV, request and alignment hashes.
An ambiguous transport failure at submission is a hard stop requiring explicit
job reconciliation; the adapter never blindly resubmits it.

```sh
docker run --rm -v "$PWD":/repo \
  -v /Users/daniel/DocBits/envs/dev/eu/doc2api.env:/run/tts-credential:ro \
  core6274-video python tts.py --online --credential-file /run/tts-credential
```

The provider is DigitalOcean `/v1/async-invoke`, with
`fal-ai/elevenlabs/tts/multilingual-v2`, explicit Rachel voice ID, fixed voice
settings, language code and `timestamps: true`. See [DigitalOcean's API](https://docs.digitalocean.com/products/inference/reference/api/serverless-inference/),
[fal's input schema](https://fal.ai/models/fal-ai/elevenlabs/tts/multilingual-v2/api)
and [ElevenLabs' voice ID reference](https://elevenlabs.io/docs/api-reference/voices/get).

Observed responses contain character-alignment blocks, not the documented
word-list shape. Both are validated. Japanese responses transliterate kanji with
incorrect readings, so the Japanese speech snapshot uses explicit kana readings;
its captions remain normal Japanese. The transliterated alignment does not match
native caption tokens, so Japanese uses measured segment captions. EN/DE use
validated word alignment. HU uses the exact EN audio cache entries, native reading
holds, Hungarian captions/visuals, and the visible `Angol hang` badge.

## R5 corrected-script review

The corrected fifteen-segment script and teaching diagrams replace the original
short text-card pilot. PM approved publication up to 120 seconds (R7); API, Web,
and pipeline schemas agree. The four reviewed variants run 99–117 seconds.
Key-frame export includes setup/action/result frames, 380px drawer samples and a
fifteen-scene contact sheet per language.

## Local rendering and QA

```sh
docker run --rm --network none -v "$PWD":/repo core6274-video python build.py
docker run --rm --network none -v "$PWD":/repo core6274-video python qa.py --all
docker run --rm --network none -v "$PWD":/repo \
  -v /absolute/local/qa-directory:/qa core6274-video python qa.py --keyframes /qa
```

`--locale en` selects one approved variant. `--prepare-only` checks timing without
rendering; `--manifest-only` rebuilds the candidate manifest from all four local
outputs. `--out` isolates a build. The normal build is always offline; no network
flag exists on `build.py`. Missing/corrupt caches fail instead of regenerating.

Speech is placed after a 250ms lead and receives at least a 500ms tail. The frame
budget is the ceiling of measured PCM duration/native reading time at 30fps.
Manim sections are normalized individually to that exact budget before joining;
more than two frames of renderer rounding drift is rejected. No narration is
trimmed or stretched. Two-pass measured loudness targets -16 LUFS with -2 dBTP limiter headroom
to keep final AAC at or below -1 dBTP;
final AAC measurements are checked independently. Encoding is H.264 Main yuv420p,
720p30, AAC-LC 48kHz stereo/96kbps, faststart and a maximum 60-frame GOP. An
oversized CRF20 output gets a deterministic two-pass bitrate budget, then fails if
still over 10,000,000 bytes. Every final MP4 receives a complete error-failing decode.

The VTT, inline cues and normalized transcript share one serializer. Page input
hashes include the frozen content, actual audio/alignment hashes, timing, scene
code, fonts, toolchain, routes and encoding. Final artifact hashes derive the content hash retained in provenance. The public
version is a positive integer selected with `--version N` (default 1). Increment
N for changed media; existing version objects cannot be overwritten. `pilot.manifest.candidate.json` is strictly
local and is **not** a runtime/published manifest. Its schema snapshot is extracted
from plan v2 and semantically compared with R1's canonical schema; the canonical
contract files remain owned by R1.

Renderer tests run in the isolated renderer, without importing the API/Celery conftests:

```sh
docker run --rm --network none -v "$PWD":/repo -w /repo core6274-video \
  python -m pytest -p no:rerunfailures --noconftest -o addopts= \
  tests/unit/test_CORE_6274_video_*.py
```

No earlier renderer tests exist nearby. Tests cover real synthetic encoding and
byte reproduction as well as mocked provider failures. No unit test submits TTS.
Text/glyph checks include Japanese and Hungarian double accents. Visual frames
still require inspection; objective checks do not certify audible pronunciation.
See the checked-in pilot QA report for the remaining listening gate. Publishing,
public headers/ranges, browser playback and bulk rendering belong to later runs.

## Publish verified pilot (R7)

From the repository root, with local Python dependencies `boto3`, `requests`,
`python-dotenv`, and `jsonschema` installed, after build and QA:

```sh
python scripts/settings_assistant/explainer_videos/publish.py --upload --receipt /absolute/path/pilot-publish.json
```

Without `--upload`, this performs anonymous verification only. Credentials are
loaded with `dotenv_values` from `/Users/daniel/DocBits/envs/dev/eu/doc2api.env`:
`S3_KEY` and `S3_SECRET`; never shell-source or print values. Upload endpoint:
`https://fra1.digitaloceanspaces.com`, bucket `docbits-videos`, public-read ACL,
`public, max-age=31536000, immutable`. Keys are exclusively
`settings-assistant/<page_key>/v<N>/<locale>.{mp4,vtt,png}`.
Existing objects are never overwritten or deleted, including `manifest.json`
and `videos/*`. Conditional creation fails closed on a conflict. Identical existing
assets are reused and must pass verification without ACL/metadata repair.
The only public runtime origin is
`https://docbits-videos.fra1.cdn.digitaloceanspaces.com`.
Verification requires anonymous 200 GETs, exact MIME/bytes/SHA-256/cache headers,
and 206 byte ranges for all twelve objects. Only after a successful receipt,
copy the candidate to both API `helpers/settings_assistant/page_videos.json`
and derive both Web `src/utils/settingsAssistant/pageVideoCatalog.json` files
as `{page: {content_revision: sorted_locales}}`. Pilot catalogs contain layouts
only. Deploy API manifests before enabling the Web catalog; merge VESTA first.

Publisher tests use the local Python environment with boto3 (kept outside the
locked offline renderer):

```sh
python -m pytest -p no:rerunfailures --noconftest -o addopts= tests/unit/test_CORE_6274_publish.py
```
