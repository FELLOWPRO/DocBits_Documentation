---
name: docbits-explainer-videos
description: Create, review, render, and publish narrated DocBits settings-page explainers with the existing Manim pipeline. Use for “Erklärvideo”, “3b1b Video”, “Video mit Audio für Settings-Seite”, and localized Settings Assistant video requests.
---

# DocBits settings explainers

Use the existing pipeline in the API repository, `scripts/settings_assistant/explainer_videos/`.
The reference worktree is `/Users/daniel/DocBits/doc2-api/.claude/worktrees/core6274-video-pipeline`;
its paired branch is `feature/CORE-6274_video-pipeline-nova`. Discover current worktrees
with `git -C /Users/daniel/DocBits/doc2-api worktree list` and
`git -C /Users/daniel/DocBits/doc2app worktree list`; inspect status and local instructions
before editing. Read the pipeline README, current page script, scene, locks, and QA reports.
The initial pilot is `layouts × en/de/ja/hu`; another page requires its own content and
scene implementation, not merely renaming layouts. Preserve user-authorized scope.

## Credentials and environment

Names and location only: `/Users/daniel/DocBits/envs/dev/eu/doc2api.env` contains
`TOUCHLESS_ADVISOR_API_KEY` for TTS and `S3_KEY` / `S3_SECRET` for uploads.
Load with Python `dotenv_values` from `python-dotenv`. Never shell-source this file,
print secret values, put them in command arguments, or include them in receipts.
For Docker TTS, mount it read-only at `/run/tts-credential` and pass that path.

Use the retained `core6274-video` renderer and verify `toolchain.lock.json`,
`fonts.lock.json`, `brand.lock.json`, and `requirements.lock`. The reference environment
uses Python 3.11.11, Manim Community 0.19.0/Cairo, FFmpeg 7.1.1 and 720p30 rendering.
`toolchain.py` rejects drift. Do not freeze a new lock simply to bypass failure.
The checksum-pinned logo is retained under `cache/brand/`; fonts are in the pipeline
cache. Read the README for provisioning; rebuild a missing image only as an explicit
provisioning step. Retain cached TTS and source snapshots with build artifacts.

## Content and visual teaching

Write `content/<page_key>/script.yaml`, `labels.yaml`, and `locales/<locale>.json`.
The existing YAML files use JSON syntax (valid YAML); current loaders call `json.loads`,
so preserve that representation unless deliberately updating the loaders and tests.
Use controlled STE-style English: short active sentences, one instruction or causal
claim per sentence, consistent UI terminology, concrete examples, and no unexplained
pronouns. Verify statements against both VESTA and NOVA UI behavior. Do not invent
controls or demonstrate customer data.

Keep stable `segment_ids`, ordered scenes, and coverage mapping. Each localized
segment has matching `id` and `scene_id`, narration and caption text; label dictionaries
supply localized diagram labels. Preserve meaning and order across locales. Review
back-translations and pronunciation, especially Japanese kanji readings. A separate
kana speech snapshot can improve pronunciation while captions remain normal Japanese.

Supported app locales: en de it fr es nl zh bg cs hu ja ko pl pt pt-br ro sk sl sv th tr vi.
Keep `pt` and `pt-br` distinct. HU/SL/TH/VI use the exact English audio cache, native
captions/transcript, localized visual labels, and a localized “English audio” badge.
Do not ask the voice provider to synthesize these four languages.

Implement `scenes/<page_key>.py` using `scenes/common.py` and `brand.py`. The layouts
scene is the working reference for timed Manim sections, narration cue placement,
setup → action → result diagrams, selection rules and branch logic. Use diagrams
that explain state changes; avoid filling every shot with narration paragraphs.
The brand uses dark navy `#0A2531`, panel `#0F3342`, white `#F5F5F5`, muted text
`#9FBDC9`, cyan `#4DB6DA`, and green `#34EEA9`. Preserve the pinned white DocBits logo,
16:9 layout, generous text margins and restrained motion. Adapt the build dispatch,
route map and tests when adding a new scene: the pilot CLI initially supports layouts.

## Speech, timing and reproducibility

TTS uses DigitalOcean `https://inference.do-ai.run/v1/async-invoke` with model
`fal-ai/elevenlabs/tts/multilingual-v2`, `timestamps: true`, the fixed voice ID and
settings in `voice_settings.json`, and an explicit language code. Use `tts.py`;
do not implement a second uncached provider client.

From the API worktree root, when speech acquisition is authorized:

```sh
docker run --rm -v "$PWD":/repo \
  -v /Users/daniel/DocBits/envs/dev/eu/doc2api.env:/run/tts-credential:ro \
  core6274-video python tts.py --online --credential-file /run/tts-credential
```

Cache each segment by the full request hash in `cache/tts/`, including original MP3,
decoded WAV, alignment, request ID, and completion checksums. Reuse valid hits.
Persist asynchronous request IDs before polling; resume a known request after timeout.
An ambiguous submission failure must be reconciled before resubmission to avoid
repeated paid requests. The adapter's HTTP timeout is 60 seconds and polling deadline
300 seconds; a slow job is not evidence that submission failed.

Provider responses can contain character alignment rather than word lists. Validate
alignment against speech text; do not assume native Japanese captions match a
transliterated provider response. EN/DE use verified word timing; Japanese and
English-audio fallback locales use measured segment captions and native reading holds.
Timing includes a 250ms lead and at least a 500ms tail, rounded up to 30fps frames.
Never trim or stretch narration to fit. Aim for 60–120 seconds; the PM publication
ceiling is 120,000ms, shared by pipeline/API/Web contracts.

## Build, mux and review

From the API worktree root:

```sh
docker run --rm --network none -v "$PWD":/repo core6274-video python build.py
docker run --rm --network none -v "$PWD":/repo core6274-video python qa.py --all
docker run --rm --network none -v "$PWD":/repo \
  -v /absolute/local/qa-directory:/qa core6274-video python qa.py --keyframes /qa
```

`--version N` selects the positive integer public version (default 1); increment
it for changed media. Keep content/file hashes in manifests/provenance only.
`--locale en` selects a pilot locale; `--prepare-only` checks timing, `--manifest-only`
reassembles the candidate, and `--out` isolates iterations. Use the same output root
for build and QA. Changed content/scene/input hashes require rebuilding the affected
variants, followed by regenerating the page manifest. Reuse speech cache unchanged.

Mux H.264 Main/yuv420p, 1280×720/30fps, AAC-LC 48kHz stereo/96kbps, faststart,
maximum 60-frame GOP and 10,000,000 bytes. Measured two-pass loudness targets −16 LUFS;
check the final AAC true peak, not only the intermediate WAV. The encoder has a
bitrate-budget fallback for oversized CRF output. Run full decode, duration, stream,
hash, VTT/inline cue equality and manifest validation. Review contact sheets,
setup/action/result frames, and 380px samples; listen to full native audio.

Common pitfalls from the pilot workflow:
- Async timeouts: preserve and resume request IDs; never blindly repeat submission.
- Font fallback: pin explicit Noto JP/SC/KR/Thai faces and symbol fallbacks. Test real
  glyphs (including Japanese and Hungarian accents); Latin success proves little.
- Contrast at 380px: small muted labels can disappear against navy panels. Inspect
  actual downscaled frames, enlarge key labels and use the brighter brand colors.
- Readability: native captions may need more time than English narration. Add holds
  and split cues; do not compress captions to meet an obsolete 90-second ceiling.
- Long renders: save logs, use resumable locale jobs and allow the render to finish.
  A silent terminal does not mean Manim is stuck.
- A passing machine QA report does not certify pronunciation, explanatory accuracy,
  or browser accessibility. Record listening and visual review separately.

Iterate script/labels/scene → cached speech acquisition if needed → offline build →
QA/contact sheets/listening → review fixes. Do not publish a stale candidate after
changing source inputs or media. Keep failed review artifacts separate.

## Publish, then expose in API and Web

Publication requires user authorization (an explicit publish request suffices).
Run `publish.py` with local Python dependencies boto3, requests, python-dotenv and
jsonschema after QA:

```sh
python scripts/settings_assistant/explainer_videos/publish.py \
  --upload --receipt /absolute/path/pilot-publish.json
```

Physical Space: `docbits-videos`, region fra1. S3 endpoint:
`https://fra1.digitaloceanspaces.com`. Canonical runtime/CDN origin:
`https://docbits-videos.fra1.cdn.digitaloceanspaces.com`.
Only keys `settings-assistant/<page_key>/v<N>/<locale>.{mp4,vtt,png}` are allowed.
Use public-read ACL and `public, max-age=31536000, immutable` cache headers. Never
rewrite or delete existing objects, especially root `manifest.json` and `videos/*`.
Existing identical assets are reused; conflicts require a new integer version.
Create-only `IfNoneMatch="*"` must not be removed to bypass a provider error.

The publisher verifies anonymous CDN GET 200, MIME, byte length, SHA-256, immutable
cache headers and Range 206/content-range/body before writing a successful receipt.
Without `--upload`, it only re-verifies. Do not use signed URLs, S3 GETs, or HEAD alone
as evidence of anonymous CDN playback.

After verification, copy `out/pilot.manifest.candidate.json` into
`helpers/settings_assistant/page_videos.json` on both API tracks. Derive both Web
`src/utils/settingsAssistant/pageVideoCatalog.json` files as
`{page_key: {content_revision: sorted_locale_list}}`; the pilot is layouts only.
Keep all four `contracts/settings_assistant/page_video_*.json` copies byte-identical.
The track-specific `chat_request.openapi.json` is separate from this parity set.
Never advertise an unpublished locale. APIs must deploy before the Web catalog.

## Paired delivery and review loop

Use paired `feature/CORE-6274_<topic>` / `feature/CORE-6274_<topic>-nova` branches,
base dev / dev-nova, respectively, and preserve existing worktrees. Stage explicit
paths; format touched Python with Black line length 88/target py312; run API pytest
with `-p no:rerunfailures`, pipeline tests, Web touched Vitest specs, lint and vue-tsc.
Publisher tests use local boto3; renderer tests run in the locked image. Validate
new assets against both actual API resolvers and the Web parser/catalog.

Push without force, cross-link the PR pair, say “merge VESTA first”, attach public
verification receipts and honest QA results, and follow the active session's commit
footer rules. Do not merge or deploy other environments without authorization.
After deployment, check the effective CSP and actual anonymous playback/seek,
captions, English-audio badge, transcript/error/retry paths, 380px readability and
keyboard access on both tracks. Report browser checks separately from publication
and unit tests. Return review findings to the owning paired branches, rebuild and
re-verify affected assets, and keep prior immutable revisions available.
