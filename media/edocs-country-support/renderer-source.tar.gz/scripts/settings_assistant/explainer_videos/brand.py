"""DocBits palette and panel treatment reused from the supplied promo scene."""

BG = "#0A2531"
SURFACE = "#0F3342"
BORDER = "#2E6477"
INK = "#F5F5F5"
MUTED = "#9FBDC9"
PRIMARY = "#2389AF"
CYAN = "#4DB6DA"
GREEN = "#34EEA9"
AMBER = "#E9B96E"
ERROR = "#F07178"
FRAME_WIDTH = 16
FRAME_HEIGHT = 9
