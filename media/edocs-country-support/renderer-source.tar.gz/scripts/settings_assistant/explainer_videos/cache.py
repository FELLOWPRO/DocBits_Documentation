"""Content addressed storage; completed entries are immutable and verified."""

import hashlib
import json
import os
from pathlib import Path


def canonical(value):
    return json.dumps(
        value, sort_keys=True, ensure_ascii=False, separators=(",", ":")
    ).encode()


def digest(value):
    return hashlib.sha256(value).hexdigest()


def file_hash(path):
    return digest(Path(path).read_bytes())


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_bytes(canonical(value) + b"\n")
    os.replace(temporary, path)


def verify_entry(directory):
    directory = Path(directory)
    metadata = json.loads((directory / "complete.json").read_text())
    required = {
        "original.mp3",
        "speech.wav",
        "alignment.json",
        "raw_alignment.json",
        "request.json",
    }
    if set(metadata["files"]) != required:
        raise ValueError("Incomplete TTS cache inventory")
    if (
        digest(canonical(json.loads((directory / "request.json").read_text())))
        != directory.name
    ):
        raise ValueError("TTS request fingerprint mismatch")
    for name, expected in metadata["files"].items():
        if name not in {
            "original.mp3",
            "speech.wav",
            "alignment.json",
            "raw_alignment.json",
            "request.json",
        }:
            raise ValueError("Unexpected cache file")
        if file_hash(directory / name) != expected:
            raise ValueError("TTS cache corruption")
    return metadata
