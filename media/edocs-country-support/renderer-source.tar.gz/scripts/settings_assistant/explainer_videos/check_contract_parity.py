"""Compare exact contract bytes in two or more API/Web checkout roots.

Release invocation supplies all four roots; R1 supplies the two API roots.
Optional --web-repo checks the pinned route templates at both Web refs.
"""

import argparse
import hashlib
from pathlib import Path
import subprocess

FILES = (
    "page_video_routes.v1.json",
    "page_video_fixtures.v1.json",
    "page_video_manifest.schema.v1.json",
    "page_video_sse.schema.v1.json",
)
TEMPLATES = (
    "doc-type-settings/:doc_type/layouts",
    "doc-type-settings/:doc_type/layouts/selection-rules/new",
    "doc-type-settings/:doc_type/layouts/selection-rules/:rule_id",
    "transformation-rules/:doc_type",
    "transformation-rules/:doc_type/new",
    "transformation-rules/:doc_type/:rule_id",
    "custom-validation-rules/:doc_type",
    "custom-validation-rules/:doc_type/new",
    "custom-validation-rules/:doc_type/:rule_id",
    "fields/:type/:sub_doc_type?",
    "fields/:type/:sub_doc_type?/master-data",
    "data-validation",
    "master-data",
    "invoice-calculation",
    "users",
    "sub-organizations",
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("roots", nargs="+", type=Path)
    parser.add_argument("--release", action="store_true")
    parser.add_argument("--web-repo", type=Path)
    parser.add_argument(
        "--web-refs", nargs=2, default=["origin/dev", "origin/dev-nova"]
    )
    args = parser.parse_args()
    if len(args.roots) < 2 or (args.release and len(args.roots) != 4):
        parser.error("supply at least two roots (exactly four for --release)")
    if len({p.resolve() for p in args.roots}) != len(args.roots):
        parser.error("checkout roots must be distinct")
    for name in FILES:
        contents = [
            (p / "contracts/settings_assistant" / name).read_bytes() for p in args.roots
        ]
        if any(data != contents[0] for data in contents[1:]):
            raise SystemExit(f"Contract mismatch: {name}")
        print(f"{hashlib.sha256(contents[0]).hexdigest()}  {name}")
    if args.web_repo:
        for ref in args.web_refs:
            source = subprocess.check_output(
                [
                    "git",
                    "-C",
                    str(args.web_repo),
                    "show",
                    f"{ref}:src/router/routes.ts",
                ],
                text=True,
            )
            for template in TEMPLATES:
                if f"path: '{template}'" not in source:
                    raise SystemExit(f"Route template missing: {ref}: {template}")
    print("Contract parity passed")


if __name__ == "__main__":
    main()
