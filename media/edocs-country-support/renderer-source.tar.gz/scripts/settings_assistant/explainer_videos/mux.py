"""Deterministic PCM assembly, measured loudness normalization and MP4 encode."""

import json
import math
import subprocess
import wave
from pathlib import Path

ENCODING = [
    "-c:v",
    "libx264",
    "-profile:v",
    "main",
    "-pix_fmt",
    "yuv420p",
    "-r",
    "30",
    "-g",
    "60",
    "-keyint_min",
    "60",
    "-sc_threshold",
    "0",
    "-preset",
    "medium",
    "-threads",
    "1",
    "-c:a",
    "aac",
    # FFmpeg 7.1.1 twoloop + bitexact overshoots on the corrected EN speech.
    # The deterministic fast coder retains peak headroom (verified after AAC).
    "-aac_coder",
    "fast",
    "-profile:a",
    "aac_low",
    "-b:a",
    "96k",
    "-ar",
    "48000",
    "-ac",
    "2",
    "-movflags",
    "+faststart",
    "-map_metadata",
    "-1",
    "-fflags",
    "+bitexact",
    "-flags:a",
    "+bitexact",
]


def run(args):
    return subprocess.run(
        ["ffmpeg", "-hide_banner", "-y", *map(str, args)],
        check=True,
        capture_output=True,
        text=True,
    )


def assemble(timing, cache_root, output):
    with wave.open(str(output), "wb") as destination:
        destination.setparams((1, 2, 48000, 0, "NONE", "not compressed"))
        for segment in timing:
            with wave.open(
                str(Path(cache_root) / segment["cache_key"] / "speech.wav")
            ) as source:
                if (
                    source.getparams()[:3] != (1, 2, 48000)
                    or source.getnframes() != segment["samples"]
                ):
                    raise ValueError("Unexpected PCM format/sample count")
                audio = source.readframes(source.getnframes())
            silence_samples = segment["frames"] * 1600 - segment["samples"] - 12000
            if silence_samples < 24000:
                raise ValueError("Insufficient speech tail")
            destination.writeframes(
                b"\0" * 24000 + audio + b"\0" * (silence_samples * 2)
            )


def normalize(source, target):
    result = run(
        [
            "-i",
            source,
            "-af",
            "loudnorm=I=-16:TP=-2:LRA=11:print_format=json",
            "-f",
            "null",
            "-",
        ]
    )
    measured = json.JSONDecoder().raw_decode(result.stderr[result.stderr.rfind("{") :])[
        0
    ]
    if not all(
        math.isfinite(float(measured[k]))
        for k in ("input_i", "input_tp", "input_lra", "input_thresh", "target_offset")
    ):
        raise ValueError("Invalid loudness measurement")
    filter_text = f"loudnorm=I=-16:TP=-2:LRA=11:measured_I={measured['input_i']}:measured_TP={measured['input_tp']}:measured_LRA={measured['input_lra']}:measured_thresh={measured['input_thresh']}:offset={measured['target_offset']}:linear=true:print_format=json"
    result = run(
        [
            "-i",
            source,
            "-af",
            filter_text,
            "-ar",
            "48000",
            "-ac",
            "2",
            "-c:a",
            "pcm_s16le",
            target,
        ]
    )
    return json.JSONDecoder().raw_decode(result.stderr[result.stderr.rfind("{") :])[0]


def encode(silent, audio, target, duration, video_filter=None):
    common = [
        "-v",
        "error",
        "-i",
        silent,
        "-i",
        audio,
        "-map",
        "0:v:0",
        "-map",
        "1:a:0",
        *(["-vf", video_filter] if video_filter else []),
        *ENCODING,
    ]
    run([*common, "-crf", "20", target])
    if Path(target).stat().st_size > 10_000_000:
        bitrate = int((10_000_000 * 0.95 * 8 / duration - 96000 - 16000) / 1000)
        if bitrate < 200:
            raise ValueError("Unusable video bitrate budget")
        log = str(target) + ".pass"
        run(
            [
                *common,
                "-b:v",
                f"{bitrate}k",
                "-pass",
                "1",
                "-passlogfile",
                log,
                "-f",
                "mp4",
                "/dev/null",
            ]
        )
        run([*common, "-b:v", f"{bitrate}k", "-pass", "2", "-passlogfile", log, target])
    if Path(target).stat().st_size > 10_000_000:
        raise ValueError("MP4 still exceeds size limit")


def join_sections(work, timing):
    """Frame-normalize Manim section clips before joining; never alter speech."""
    from validate import probe

    work = Path(work)
    index_path = next((work / "media").rglob("sections/silent.json"))
    sections = {s["name"]: s for s in json.loads(index_path.read_text())}
    paths = []
    for segment in timing:
        source = index_path.parent / sections[segment["segment_id"]]["video"]
        actual = int(probe(source)["streams"][0]["nb_frames"])
        frames = segment["frames"]
        if abs(actual - frames) > 2:
            raise ValueError(
                "Scene renderer drift exceeds two-frame rounding tolerance"
            )
        target = work / (segment["segment_id"] + ".mp4")
        run(
            [
                "-v",
                "error",
                "-i",
                source,
                "-vf",
                f"tpad=stop_mode=clone:stop_duration=1,trim=end_frame={frames},setpts=PTS-STARTPTS",
                "-an",
                "-r",
                "30",
                "-c:v",
                "libx264",
                "-crf",
                "18",
                "-pix_fmt",
                "yuv420p",
                "-threads",
                "1",
                "-map_metadata",
                "-1",
                target,
            ]
        )
        if int(probe(target)["streams"][0]["nb_frames"]) != frames:
            raise ValueError("Section frame normalization failed")
        paths.append(target)
    listing = work / "sections.txt"
    listing.write_text("".join("file '" + str(p.resolve()) + "'\n" for p in paths))
    joined = work / "silent-exact.mp4"
    run(
        [
            "-v",
            "error",
            "-f",
            "concat",
            "-safe",
            "0",
            "-i",
            listing,
            "-c",
            "copy",
            "-map_metadata",
            "-1",
            joined,
        ]
    )
    return joined
