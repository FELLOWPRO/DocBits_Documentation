"""Publish validated immutable version-directory assets, then verify them anonymously at the CDN.

Credentials are loaded only for --upload. No delete, bucket policy, listing or
manifest upload operation exists. A receipt is written only after every check.
"""

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from manifest import ORIGIN, ROOT, validate_manifest

BUCKET = "docbits-videos"
ENDPOINT = "https://fra1.digitaloceanspaces.com"
CACHE_CONTROL = "public, max-age=31536000, immutable"
CREDENTIAL_FILE = "/Users/daniel/DocBits/envs/dev/eu/doc2api.env"


def objects(manifest, out):
    validate_manifest(manifest, out)
    for page, data in manifest["pages"].items():
        for locale, variant in data["variants"].items():
            for kind, asset in variant["assets"].items():
                ext = "png" if kind == "poster" else kind
                yield asset, Path(out) / page / f"{locale}.{ext}"


def upload(manifest, out, client):
    from botocore.exceptions import ClientError

    # Check all destinations before the first write. Existing identical version objects
    # are reused; never rewrite them, even to repair metadata or ACLs.
    pending = []
    for asset, path in objects(manifest, out):
        try:
            response = client.get_object(Bucket=BUCKET, Key=asset["key"])
        except ClientError as error:
            if error.response["Error"]["Code"] not in {"NoSuchKey", "404"}:
                raise
            pending.append((asset, path))
        else:
            body = response["Body"]
            try:
                checksum = hashlib.sha256(body.read()).hexdigest()
            finally:
                body.close()
            if checksum != asset["sha256"]:
                raise ValueError(
                    "Existing immutable object differs; increment --version before upload"
                )
    for asset, path in pending:
        # Atomic create-only protects against concurrent publishers. Never retry
        # without this precondition, including on unsupported-provider errors.
        client.put_object(
            Bucket=BUCKET,
            Key=asset["key"],
            Body=path.read_bytes(),
            ContentType=asset["mime"],
            CacheControl=CACHE_CONTROL,
            ACL="public-read",
            IfNoneMatch="*",
            Metadata={"sha256": asset["sha256"]},
        )


def verify(manifest, out, session):
    checks = []
    for asset, path in objects(manifest, out):
        url = ORIGIN + "/" + asset["key"]
        response = session.get(url, timeout=(15, 120), allow_redirects=False)
        if response.status_code != 200:
            raise ValueError("Anonymous CDN GET must return 200")
        mime = response.headers.get("Content-Type", "").lower().replace(" ", "")
        if mime != asset["mime"].lower().replace(" ", ""):
            raise ValueError("CDN MIME mismatch")
        if response.headers.get("Cache-Control") != CACHE_CONTROL:
            raise ValueError("CDN immutable cache header mismatch")
        if len(response.content) != asset["bytes"]:
            raise ValueError("CDN size mismatch")
        checksum = hashlib.sha256(response.content).hexdigest()
        if checksum != asset["sha256"]:
            raise ValueError("CDN checksum mismatch")
        end = min(1023, asset["bytes"] - 1)
        ranged = session.get(
            url,
            headers={"Range": f"bytes=0-{end}"},
            timeout=(15, 120),
            allow_redirects=False,
        )
        if (
            ranged.status_code != 206
            or ranged.headers.get("Content-Range") != f"bytes 0-{end}/{asset['bytes']}"
            or ranged.content != response.content[: end + 1]
        ):
            raise ValueError("CDN byte range mismatch")
        checks.append(
            {
                "url": url,
                "key": asset["key"],
                "status": 200,
                "mime": response.headers["Content-Type"],
                "bytes": len(response.content),
                "sha256": checksum,
                "cache_control": response.headers["Cache-Control"],
                "range_status": 206,
                "content_range": ranged.headers["Content-Range"],
            }
        )
    return checks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=ROOT / "out")
    parser.add_argument("--upload", action="store_true")
    parser.add_argument("--credential-file", default=CREDENTIAL_FILE)
    parser.add_argument("--receipt", type=Path, required=True)
    args = parser.parse_args()
    manifest_path = args.out / "pilot.manifest.candidate.json"
    manifest = json.loads(manifest_path.read_text())
    validate_manifest(manifest, args.out)
    if args.upload:
        import boto3
        from botocore.config import Config
        from dotenv import dotenv_values

        credentials = dotenv_values(args.credential_file)
        client = boto3.client(
            "s3",
            endpoint_url=ENDPOINT,
            region_name="fra1",
            aws_access_key_id=credentials["S3_KEY"],
            aws_secret_access_key=credentials["S3_SECRET"],
            config=Config(signature_version="s3v4", retries={"max_attempts": 0}),
        )
        upload(manifest, args.out, client)
    import requests

    with requests.Session() as session:
        # Ignore .netrc and inherited auth/proxy settings. This proves public
        # access; the S3 signing client is never used for verification.
        session.trust_env = False
        checks = verify(manifest, args.out, session)
    receipt = {
        "verified_at": datetime.now(timezone.utc).isoformat(),
        "media_origin": ORIGIN,
        "storage_bucket": BUCKET,
        "manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
        "publication_ready": True,
        "anonymous": True,
        "objects": checks,
        "pages": {
            key: {
                "content_revision": page["content_revision"],
                "locales": sorted(page["variants"]),
            }
            for key, page in manifest["pages"].items()
        },
    }
    args.receipt.write_text(json.dumps(receipt, indent=2) + "\n")
    print(f"Verified {len(checks)} public CDN assets; receipt: {args.receipt}")


if __name__ == "__main__":
    main()
