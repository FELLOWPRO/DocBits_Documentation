"""Offline page-specific educational diagrams."""
