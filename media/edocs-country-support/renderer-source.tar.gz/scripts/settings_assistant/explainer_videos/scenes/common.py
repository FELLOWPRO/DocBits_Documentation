"""Readable, bounded text and restrained 3Blue1Brown-style diagram primitives."""

import json
from pathlib import Path
import numpy as np
from fontTools.ttLib import TTFont
from manim import RoundedRectangle, Text, VGroup
from brand import BORDER, SURFACE, INK

ROOT = Path(__file__).resolve().parents[1]


def font(locale):
    return (
        "Noto Sans CJK SC"
        if locale == "zh"
        else "Noto Sans CJK JP" if locale == "ja" else "Noto Sans"
    )


def check_glyphs(text, locale):
    name = (
        "NotoSansCJKsc-Regular.otf"
        if locale == "zh"
        else "NotoSansCJKjp-Regular.otf" if locale == "ja" else "NotoSans-Regular.ttf"
    )
    with TTFont(ROOT / "cache/fonts" / name) as face:
        available = set(face.getBestCmap())
    with TTFont(ROOT / "cache/fonts/NotoSansSymbols2-Regular.ttf") as symbols:
        available.update(symbols.getBestCmap())
    with TTFont(ROOT / "cache/fonts/NotoSansSymbols-Regular.ttf") as symbols:
        available.update(symbols.getBestCmap())
    with TTFont(ROOT / "cache/fonts/NotoSansMath-Regular.ttf") as symbols:
        available.update(symbols.getBestCmap())
    missing = {
        character
        for character in text
        if not character.isspace() and ord(character) not in available
    }
    if missing:
        raise ValueError(f"Missing glyphs: {sorted(missing)}")


def label(text, locale, color=INK, max_width=14, size=52):
    check_glyphs(text, locale)
    item = Text(
        text, font=font(locale), font_size=size, color=color, disable_ligatures=False
    )
    # Wrap at native word boundaries, never shrink essential text to fit.
    if item.width > max_width:
        words = text.split()
        choices = []
        for split in range(1, len(words)):
            wrapped = " ".join(words[:split]) + "\n" + " ".join(words[split:])
            candidate = Text(wrapped, font=font(locale), font_size=size, color=color)
            if candidate.width <= max_width:
                choices.append(candidate)
        if not choices:
            raise ValueError(f"Visual label exceeds width: {text}")
        item = min(choices, key=lambda candidate: candidate.width)
    if size * 4 / 3 < 54:
        raise ValueError("Essential text is too small at drawer width")
    return item


def panel(text, locale, color=INK, width=13.8):
    item = label(text, locale, color, max_width=width - 0.6)
    box = RoundedRectangle(
        width=width,
        height=max(1.4, item.height + 0.35),
        corner_radius=0.14,
        stroke_color=BORDER,
        stroke_width=2,
        fill_color=SURFACE,
        fill_opacity=1,
    )
    item.move_to(box)
    return VGroup(box, item)
