from country_scene import CountryScene


class Edocs_country_australia(CountryScene):
    page_key = 'edocs_country_australia'
