from country_scene import CountryScene


class Edocs_country_china(CountryScene):
    page_key = 'edocs_country_china'
