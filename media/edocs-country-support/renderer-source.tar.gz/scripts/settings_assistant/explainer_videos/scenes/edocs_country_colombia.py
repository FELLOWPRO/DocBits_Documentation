from country_scene import CountryScene


class Edocs_country_colombia(CountryScene):
    page_key = 'edocs_country_colombia'
