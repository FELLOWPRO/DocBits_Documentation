from country_scene import CountryScene


class Edocs_country_costa_rica(CountryScene):
    page_key = 'edocs_country_costa_rica'
