from country_scene import CountryScene


class Edocs_country_ecuador(CountryScene):
    page_key = 'edocs_country_ecuador'
