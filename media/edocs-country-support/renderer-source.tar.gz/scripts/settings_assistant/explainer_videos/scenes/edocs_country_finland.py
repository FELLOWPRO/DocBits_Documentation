from country_scene import CountryScene


class Edocs_country_finland(CountryScene):
    page_key = 'edocs_country_finland'
