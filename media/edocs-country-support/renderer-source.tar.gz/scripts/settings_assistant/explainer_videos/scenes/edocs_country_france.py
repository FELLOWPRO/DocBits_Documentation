from country_scene import CountryScene


class Edocs_country_france(CountryScene):
    page_key = 'edocs_country_france'
