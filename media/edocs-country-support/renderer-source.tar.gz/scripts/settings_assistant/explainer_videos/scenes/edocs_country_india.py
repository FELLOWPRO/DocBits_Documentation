from country_scene import CountryScene


class Edocs_country_india(CountryScene):
    page_key = 'edocs_country_india'
