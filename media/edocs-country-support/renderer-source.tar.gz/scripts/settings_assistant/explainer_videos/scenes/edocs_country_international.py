from country_scene import CountryScene


class Edocs_country_international(CountryScene):
    page_key = 'edocs_country_international'
