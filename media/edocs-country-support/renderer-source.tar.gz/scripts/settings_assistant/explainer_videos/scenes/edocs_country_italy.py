from country_scene import CountryScene


class Edocs_country_italy(CountryScene):
    page_key = 'edocs_country_italy'
