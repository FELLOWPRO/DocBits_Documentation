from country_scene import CountryScene


class Edocs_country_korea(CountryScene):
    page_key = 'edocs_country_korea'
