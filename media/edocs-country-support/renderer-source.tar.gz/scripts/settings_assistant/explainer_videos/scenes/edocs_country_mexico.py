from country_scene import CountryScene


class Edocs_country_mexico(CountryScene):
    page_key = 'edocs_country_mexico'
