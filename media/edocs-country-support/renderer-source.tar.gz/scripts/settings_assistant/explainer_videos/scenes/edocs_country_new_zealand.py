from country_scene import CountryScene


class Edocs_country_new_zealand(CountryScene):
    page_key = 'edocs_country_new_zealand'
