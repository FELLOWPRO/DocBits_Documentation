from country_scene import CountryScene


class Edocs_country_paraguay(CountryScene):
    page_key = 'edocs_country_paraguay'
