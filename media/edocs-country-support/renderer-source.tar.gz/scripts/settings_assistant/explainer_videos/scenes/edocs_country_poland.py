from country_scene import CountryScene


class Edocs_country_poland(CountryScene):
    page_key = 'edocs_country_poland'
