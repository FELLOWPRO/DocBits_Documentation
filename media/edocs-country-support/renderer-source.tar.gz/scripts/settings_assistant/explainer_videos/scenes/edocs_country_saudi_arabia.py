from country_scene import CountryScene


class Edocs_country_saudi_arabia(CountryScene):
    page_key = 'edocs_country_saudi_arabia'
