from country_scene import CountryScene


class Edocs_country_singapore(CountryScene):
    page_key = 'edocs_country_singapore'
