from country_scene import CountryScene


class Edocs_country_slovenia(CountryScene):
    page_key = 'edocs_country_slovenia'
