from country_scene import CountryScene


class Edocs_country_taiwan(CountryScene):
    page_key = 'edocs_country_taiwan'
