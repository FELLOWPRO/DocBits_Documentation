from country_scene import CountryScene


class Edocs_country_thailand(CountryScene):
    page_key = 'edocs_country_thailand'
