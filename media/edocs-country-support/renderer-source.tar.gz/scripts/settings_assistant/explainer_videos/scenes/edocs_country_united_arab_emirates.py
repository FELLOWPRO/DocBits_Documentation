from country_scene import CountryScene


class Edocs_country_united_arab_emirates(CountryScene):
    page_key = 'edocs_country_united_arab_emirates'
