from country_scene import CountryScene


class Edocs_country_uruguay(CountryScene):
    page_key = 'edocs_country_uruguay'
