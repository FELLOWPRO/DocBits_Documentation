from country_scene import CountryScene


class Edocs_country_vietnam(CountryScene):
    page_key = 'edocs_country_vietnam'
