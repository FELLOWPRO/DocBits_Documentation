"""Layouts teaching film: fifteen concrete, synthetic UI/decision demonstrations.

UI labels are frozen from Tolgee; illustrative notes never impersonate controls.
No live organization data or server-test result is used.
"""

import json
import os
import sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from manim import (
    MovingCameraScene,
    config,
    ImageMobject,
    VGroup,
    RoundedRectangle,
    Rectangle,
    Circle,
    Arc,
    Polygon,
    Line,
    Arrow,
    Dot,
    FadeIn,
    FadeOut,
    Create,
    Transform,
    ReplacementTransform,
    TransformFromCopy,
    LaggedStart,
    MoveAlongPath,
    Indicate,
    SurroundingRectangle,
    CubicBezier,
    UP,
    DOWN,
    LEFT,
    RIGHT,
)
from brand import BG, SURFACE, BORDER, INK, CYAN, GREEN, AMBER, ERROR
from scenes.common import label

config.background_color = BG
config.frame_width = 16
config.frame_height = 9
config.pixel_width = 1280
config.pixel_height = 720
config.frame_rate = 30
config.renderer = "cairo"


class Layouts(MovingCameraScene):
    def text(self, key, point=(0, 2.5, 0), color=INK, width=13.4):
        value = self.content["labels"].get(key, self.content["notes"].get(key, key))
        return label(value, self.locale, color=color, max_width=width, size=48).move_to(
            point
        )

    def box(self, width=4, height=2.8, color=BORDER):
        return RoundedRectangle(
            width=width,
            height=height,
            corner_radius=0.18,
            stroke_color=color,
            stroke_width=3,
            fill_color=SURFACE,
            fill_opacity=1,
        )

    def button(self, key, point=(0, 0, 0), color=CYAN):
        title = self.text(key, (0, 0, 0), INK)
        return VGroup(
            self.box(max(2.4, title.width + 0.5), 0.85, color), title
        ).move_to(point)

    def document(self, point=(-5, 0, 0), filled=True, color=CYAN):
        paper = self.box(2.1, 2.7, color)
        corner = Polygon(
            [0.53, 1.35, 0],
            [1.05, 0.83, 0],
            [0.53, 0.83, 0],
            stroke_color=color,
            fill_color=BG,
            fill_opacity=1,
        )
        rows = VGroup(
            *[
                Line(
                    [-0.68, y, 0],
                    [0.62 if n else 0.13, y, 0],
                    color=color,
                    stroke_width=5,
                )
                for n, y in enumerate([0.55, 0.05, -0.45, -0.9])
            ]
        )
        if not filled:
            rows.set_opacity(0)
        return VGroup(paper, corner, rows).move_to(point)

    def form(self, point=(4, 0, 0), filled=True, color=CYAN):
        body = self.box(3.1, 2.7, color)
        rows = VGroup(
            *[self.box(2.35, 0.38, color).move_to([0, y, 0]) for y in [0.75, 0, -0.75]]
        )
        if not filled:
            rows.set_opacity(0)
        return VGroup(body, rows).move_to(point)

    def mark(self, point, yes=True):
        if yes:
            shape = VGroup(
                Line([-0.28, 0, 0], [-0.07, -0.23, 0]),
                Line([-0.07, -0.23, 0], [0.35, 0.3, 0]),
            )
        else:
            shape = VGroup(
                Line([-0.25, -0.25, 0], [0.25, 0.25, 0]),
                Line([-0.25, 0.25, 0], [0.25, -0.25, 0]),
            )
        return shape.set_stroke(GREEN if yes else ERROR, 7).move_to(point)

    def lock(self, point):
        return VGroup(
            self.box(0.65, 0.5, AMBER),
            Arc(radius=0.23, start_angle=0, angle=np.pi, color=AMBER).shift(UP * 0.25),
        ).move_to(point)

    def pencil(self, point):
        return VGroup(
            Line([-0.3, -0.3, 0], [0.3, 0.3, 0], color=CYAN, stroke_width=10),
            Polygon(
                [-0.4, -0.4, 0],
                [-0.3, -0.1, 0],
                [-0.1, -0.3, 0],
                fill_color=INK,
                fill_opacity=1,
                stroke_width=0,
            ),
        ).move_to(point)

    def toggle(self, point, on=False):
        color = GREEN if on else BORDER
        return VGroup(
            self.box(1.25, 0.58, color),
            Dot([0.32 if on else -0.32, 0, 0], radius=0.2, color=color),
        ).move_to(point)

    def arrow(self, a, b, color=CYAN):
        return Arrow(
            a,
            b,
            buff=0.12,
            color=color,
            stroke_width=5,
            max_tip_length_to_length_ratio=0.18,
        )

    def focus(self, item, color=CYAN):
        # Highlight the outline without turning text and its fill the same color.
        outline = SurroundingRectangle(
            item, buff=0.12, color=color, stroke_width=4, fill_opacity=0
        )
        return Indicate(outline, color=color, scale_factor=1.04, remover=True)

    def beat(self, fraction, *animations):
        """Give a teaching action motion, then a readable hold within speech timing."""
        frames = max(1, round(self.body_frames * fraction))
        motion = min(33, max(9, round(frames * 0.48)))
        motion = min(motion, frames)
        self.play(*animations, run_time=motion / 30)
        if frames > motion:
            self.wait((frames - motion) / 30)

    def rule_rows(self):
        rows = VGroup()
        for i, y in enumerate([1.5, 0, -1.5]):
            grip = VGroup(
                *[
                    Dot([x, dy, 0], radius=0.035, color=BORDER)
                    for x in [-0.09, 0.09]
                    for dy in [-0.16, 0, 0.16]
                ]
            )
            grip.move_to([-5.65, y, 0])
            box = self.box(9.8, 1.1).move_to([0, y, 0])
            rank = self.text(str((i + 1) * 10), [-4.4, y, 0], CYAN)
            # One condition symbol and a form thumbnail: no dense table text.
            symbol = self.text("A" if i == 1 else "B", [-1.8, y, 0], CYAN)
            if i == 0:
                symbol = self.text("∅", [-1.8, y, 0], AMBER)
            target = self.form([3.65, y, 0], color=AMBER if i == 0 else CYAN).scale(
                0.27
            )
            rows.add(VGroup(box, grip, rank, symbol, target))
        return rows

    def scope(self):
        stages = VGroup(
            *[
                self.text(
                    k,
                    [(-3.5 if i % 2 == 0 else 3.5), (1.8 if i < 2 else -0.6), 0],
                    CYAN,
                    6.4,
                )
                for i, k in enumerate(
                    ["field_validation", "approval", "reject", "review"]
                )
            ]
        )
        self.beat(
            0.24,
            LaggedStart(*[FadeIn(x, shift=UP * 0.15) for x in stages], lag_ratio=0.18),
        )
        one = self.document([-2.8, -0.6, 0]).scale(0.55)
        two = self.document([0.7, -0.6, 0]).scale(0.55)
        nums = VGroup(self.text("1", [-2.8, -0.6, 0]), self.text("2", [0.7, -0.6, 0]))
        arrows = VGroup(
            self.arrow([-2.8, 0.15, 0], stages[1].get_bottom()),
            self.arrow([0.7, 0.15, 0], stages[1].get_bottom()),
        )
        self.beat(
            0.24,
            *[FadeOut(stages[i]) for i in (0, 2, 3)],
            FadeIn(one),
            FadeIn(two),
            FadeIn(nums),
            Create(arrows),
            self.focus(stages[1]),
        )
        self.beat(0.06, FadeOut(VGroup(stages, one, two, nums, arrows)))
        tabs = VGroup(
            self.button(self.content["labels"]["layouts"] + "  3", [-3.4, 2.25, 0]),
            self.button(
                self.content["labels"]["selection_rules"] + "  2",
                [3.4, 2.25, 0],
                BORDER,
            ),
        )
        cards = VGroup(
            *[
                VGroup(self.form([x, -0.35, 0]), self.text(str(i + 1), [x, -2.2, 0]))
                for i, x in enumerate([-4.2, 0, 4.2])
            ]
        )
        badge = self.lock([-5.3, -2.2, 0])
        self.beat(
            0.2,
            FadeIn(tabs),
            LaggedStart(*[FadeIn(c) for c in cards], lag_ratio=0.2),
            FadeIn(badge),
        )
        rules = self.rule_rows().shift(DOWN * 0.65)
        self.beat(
            0.24,
            self.focus(tabs[1], color=GREEN),
            ReplacementTransform(cards, rules),
            FadeOut(badge),
        )

    def status(self):
        title = self.text("approval")
        doc = self.document([-4.8, -0.3, 0], filled=False)
        value = self.text("1", [-4.8, -0.3, 0])
        forms = VGroup(
            self.box(4.8, 1.7, CYAN).move_to([3.6, 1, 0]),
            self.box(4.8, 1.7, CYAN).move_to([3.6, -1.55, 0]),
        )
        numbers = VGroup(
            self.text("layout_one", [3.6, 1, 0], width=4),
            self.text("layout_two", [3.6, -1.55, 0], width=4),
        )
        name = self.text("doc.status", [-1.1, 1.0, 0], CYAN)
        path = self.arrow([-3.5, -0.3, 0], [1, 1, 0])
        self.beat(
            0.25,
            FadeIn(title),
            FadeIn(doc),
            FadeIn(value),
            FadeIn(forms),
            FadeIn(numbers),
            FadeIn(name),
        )
        self.beat(0.3, Create(path), self.focus(forms[0], color=GREEN))
        self.beat(
            0.4,
            Transform(value, self.text("2", [-4.8, -0.3, 0])),
            Transform(path, self.arrow([-3.5, -0.3, 0], [1, -1.55, 0])),
            self.focus(forms[1], color=GREEN),
        )

    def clone(self):
        system = self.form([-3.6, -0.1, 0])
        lock = self.lock([-3.6, -0.1, 0])
        badge = self.text("system_default", [-3.6, 2.2, 0], AMBER, 6.3)
        clone = self.button("clone", [3.5, 2.2, 0])
        view = self.text("view", [-3.6, -2.4, 0])
        self.beat(
            0.14,
            FadeIn(system),
            FadeIn(lock),
            FadeIn(badge),
            FadeIn(clone),
            FadeIn(view),
        )
        own = self.form([3.5, -0.1, 0], color=GREEN)
        edit = self.button("edit", [3.5, -2.4, 0], GREEN)
        self.beat(
            0.22,
            TransformFromCopy(system, own),
            self.focus(clone),
            FadeIn(edit),
            FadeIn(self.pencil([3.5, -0.1, 0])),
        )
        old = list(self.mobjects)
        self.beat(0.06, *[FadeOut(m) for m in old if m not in self.chrome])
        empty = VGroup(
            self.form([0, -0.1, 0], filled=False),
            self.text("empty", [0, -0.1, 0], width=4),
        )
        new = self.button("new_layout", [0, 2.2, 0])
        self.beat(0.2, FadeIn(new), FadeIn(empty))
        populated = VGroup(
            self.form([0, -0.1, 0], color=GREEN), self.text("layouts", [0, -2.1, 0])
        )
        self.beat(
            0.3,
            ReplacementTransform(empty, populated),
            self.focus(new, color=GREEN),
            FadeIn(self.mark([2.5, -0.1, 0])),
        )

    def engine(self):
        more = self.button("more_settings", [0, 2.5, 0])
        beta = self.text("beta=true", [0, 1.35, 0], AMBER)
        engine = self.text("manage_layouts", [-1.2, -0.1, 0])
        toggle = self.toggle([4.5, -0.1, 0])
        admin = self.lock([-5.3, -0.1, 0])
        self.beat(
            0.22,
            FadeIn(more),
            FadeIn(beta),
            FadeIn(engine),
            FadeIn(toggle),
            FadeIn(admin),
        )
        self.beat(
            0.28,
            Transform(toggle, self.toggle([4.5, -0.1, 0], True)),
            self.focus(admin),
        )
        self.beat(0.1, FadeOut(VGroup(more, beta, engine, toggle, admin)))
        row = self.box(10.8, 1.65)
        title = self.text("selection_rules")
        active = self.text("active", [-1.4, 0, 0])
        switch = self.toggle([3.8, 0, 0])
        self.beat(0.15, FadeIn(row), FadeIn(title), FadeIn(active), FadeIn(switch))
        self.beat(0.2, Transform(switch, self.toggle([3.8, 0, 0], True)))

    def identity(self):
        name = self.text("rule_name", [-3.6, 2.25, 0])
        key = self.text("rule_key", [3.5, 2.25, 0])
        source = self.button("A", [-3.6, 0, 0])
        target = self.button("a", [3.5, 0, 0])
        pen = self.pencil([5.4, 0, 0])
        arrow = self.arrow([-1.7, 0, 0], [1.6, 0, 0])
        self.beat(
            0.3,
            FadeIn(name),
            FadeIn(source),
            FadeIn(key),
            Create(arrow),
            FadeIn(target),
            FadeIn(pen),
        )
        create = self.button("create_rule", [0, -2.2, 0], GREEN)
        self.beat(0.25, FadeIn(create), self.focus(pen))
        self.beat(
            0.38,
            self.focus(create),
            ReplacementTransform(pen, self.lock([5.4, 0, 0])),
            self.camera.frame.animate.scale(0.98).move_to([0, 0, 0]),
        )

    def conditions(self):
        mode = self.button("all", [0, 2.45, 0])
        doc = self.document([-5.3, -0.25, 0])
        cond = VGroup(
            self.text("supplier", [-0.25, 0.8, 0], INK, 6.4),
            self.text("sub_organization", [-0.25, -0.65, 0], INK, 6.4),
        )
        yes = self.mark([3.5, 0.8, 0])
        no = self.mark([3.5, -0.65, 0], False)
        result = self.mark([5.6, -0.25, 0], False)
        self.beat(0.12, FadeIn(mode), FadeIn(doc), FadeIn(cond))
        self.beat(0.12, Create(yes))
        self.beat(0.12, Create(no), Create(result))
        self.beat(
            0.16,
            ReplacementTransform(mode, self.button("any", [0, 2.45, 0])),
            ReplacementTransform(result, self.mark([5.6, -0.25, 0])),
            self.focus(yes),
        )
        old = [m for m in self.mobjects if m not in self.chrome]
        self.beat(0.05, *[FadeOut(m) for m in old])
        empty = self.box(3.8, 2.8, AMBER)
        zero = self.text("∅", [0, 0, 0], AMBER)
        warning = Polygon(
            [-0.45, -0.4, 0], [0.45, -0.4, 0], [0, 0.4, 0], color=AMBER
        ).move_to([0, 2.45, 0])
        bang = self.text("!", [0, 2.38, 0], AMBER)
        docs = VGroup(
            *[self.document([-5.4, y, 0]).scale(0.35) for y in [1.4, 0, -1.4]]
        )
        target = self.form([5, 0, 0], color=AMBER)
        route = self.arrow([2.1, 0, 0], [3.35, 0, 0], AMBER)
        self.beat(
            0.12,
            FadeIn(empty),
            FadeIn(zero),
            FadeIn(warning),
            FadeIn(bang),
            FadeIn(docs),
            FadeIn(target),
            Create(route),
        )
        self.beat(
            0.2,
            LaggedStart(
                *[MoveAlongPath(d, Line(d.get_center(), [5, 0, 0])) for d in docs],
                lag_ratio=0.2,
            ),
        )

    def priority(self):
        title = self.text("priority")
        rows = self.rule_rows()
        doc = self.document([-6.9, 0, 0]).scale(0.35)
        winner = self.mark([5.65, 1.5, 0])
        self.beat(0.2, FadeIn(title), FadeIn(rows), FadeIn(doc))
        broad = self.text("every", [0, -2.7, 0], AMBER)
        self.beat(0.2, FadeIn(broad), self.focus(rows[0], color=AMBER), FadeIn(winner))
        self.beat(0.12, FadeOut(broad), FadeOut(winner))
        # The rule identity and its target travel together; rank numbers stay slots.
        first = VGroup(rows[0][3], rows[0][4])
        second = VGroup(rows[1][3], rows[1][4])
        self.beat(0.25, first.animate.shift(DOWN * 1.5), second.animate.shift(UP * 1.5))
        self.beat(
            0.18,
            FadeIn(self.mark([5.65, 1.5, 0])),
            self.focus(second, color=GREEN),
            FadeIn(self.text("specific", [0, -2.7, 0], GREEN)),
        )

    def target(self):
        title = self.text("target_layout")
        doc = self.document([-5.5, 0, 0])
        empty = self.form([0.0, 1, 0], filled=False).scale(0.72)
        live = self.form([4.7, -1.0, 0], color=GREEN).scale(0.82)
        first = self.arrow([-4.2, 0, 0], [-1.3, 1, 0])
        no = self.mark([1.8, 1, 0], False)
        self.beat(0.23, FadeIn(title), FadeIn(doc), FadeIn(empty), FadeIn(live))
        self.beat(0.2, Create(first), FadeIn(no), self.focus(empty, color=ERROR))
        # Crossed-out deleted target is skipped just like an empty target.
        self.beat(0.15, FadeOut(empty), self.focus(no, color=ERROR))
        chosen = self.arrow([-4.2, -0.4, 0], [3.2, -1, 0], GREEN)
        self.beat(
            0.34,
            ReplacementTransform(first, chosen),
            FadeIn(self.mark([6.5, -1, 0])),
            self.focus(live, color=GREEN),
        )

    def fallback(self):
        doc = self.document([-5.5, 0, 0]).scale(0.75)
        default = self.form([2.5, 0, 0], color=GREEN)
        title = self.text("default_layout", [2.5, 2.3, 0], INK, 8)
        no = self.mark([-3.2, 1.3, 0], False)
        arrow = self.arrow([-4.4, 0, 0], [0.8, 0, 0], GREEN)
        self.beat(0.25, FadeIn(doc), FadeIn(default), FadeIn(title), FadeIn(no))
        self.beat(0.35, Create(arrow), self.focus(default, color=GREEN))
        # Narration explains the alternate origin route if no usable default exists.
        # Keep the successful default example visible and clearly labelled.
        origin = self.text("origin", [-1, -2.5, 0], INK)
        alternate = self.arrow([-5.5, -1.2, 0], [-2.4, -2.5, 0], CYAN)
        self.beat(0.2, FadeIn(origin), Create(alternate))
        self.beat(0.13, self.focus(default, color=GREEN))

    def reorder(self):
        rows = self.rule_rows().shift(DOWN * 0.4)
        search = self.button("A", [0, 2.5, 0])
        lock = self.lock([-5.6, 2.5, 0])
        self.beat(0.22, FadeIn(search), FadeIn(lock), FadeIn(rows))
        self.beat(
            0.2,
            Transform(search, self.button("search", [0, 2.5, 0])),
            FadeOut(lock),
        )
        first = VGroup(rows[0][3], rows[0][4])
        third = VGroup(rows[2][3], rows[2][4])
        a = first.get_center()
        b = third.get_center()
        path = CubicBezier(a, a + LEFT * 1.2, b + LEFT * 1.2, b)
        path2 = CubicBezier(b, b + RIGHT * 1.2, a + RIGHT * 1.2, a)
        self.beat(
            0.32,
            MoveAlongPath(first, path),
            MoveAlongPath(third, path2),
            self.focus(rows[0][1], color=CYAN),
        )
        self.beat(0.2, FadeIn(self.mark([5.7, 1.1, 0])), self.focus(third, color=GREEN))

    def preview(self):
        draft = self.form([-3.9, 0, 0])
        title = self.text("local", [0, 2.5, 0], CYAN)
        frame = self.box(4.5, 3.4).move_to([3.5, 0, 0])
        preview = self.form([3.5, 0, 0]).scale(0.85)
        arrow = self.arrow([-2.15, 0, 0], [1, 0, 0])
        note = self.text("no_test", [0, -2.6, 0], AMBER)
        self.beat(0.3, FadeIn(title), FadeIn(draft), FadeIn(frame))
        self.beat(0.3, Create(arrow), TransformFromCopy(draft, preview))
        self.beat(0.32, FadeIn(note), self.focus(frame, color=AMBER))

    def save(self):
        draft = self.form([0, 0, 0])
        save = self.button("save_rule", [-3.8, 2.4, 0], GREEN)
        cancel = self.button("cancel", [3.8, 2.4, 0], AMBER)
        self.beat(0.2, FadeIn(draft), FadeIn(save), FadeIn(cancel))
        kept = self.form([-3.8, -0.4, 0], color=GREEN).scale(0.8)
        self.beat(
            0.28,
            TransformFromCopy(draft, kept),
            self.focus(save, color=GREEN),
            FadeIn(self.mark([-3.8, -2.4, 0])),
        )
        discarded = self.form([3.8, -0.4, 0], color=AMBER).scale(0.8)
        self.beat(0.18, TransformFromCopy(draft, discarded))
        self.beat(
            0.26,
            FadeOut(discarded, shift=DOWN * 0.4),
            self.focus(cancel, color=AMBER),
            FadeOut(draft),
        )

    def override(self):
        system = self.box(5, 2.6).move_to([-3.3, 0, 0])
        source = self.text("system_default", [-3.3, 2.3, 0], AMBER, 6.2)
        lock = self.lock([-3.3, 0, 0])
        self.beat(0.22, FadeIn(system), FadeIn(source), FadeIn(lock))
        own = self.box(5, 2.6, GREEN).move_to([3.3, 0, 0])
        name = self.text("customized", [3.3, 2.3, 0], GREEN, 6.2)
        on = self.toggle([3.3, 0, 0], True)
        self.beat(0.28, TransformFromCopy(system, own), FadeIn(name), FadeIn(on))
        self.beat(
            0.2, Transform(on, self.toggle([3.3, 0, 0])), self.focus(own, color=AMBER)
        )
        cross = VGroup(
            Line(
                system.get_corner(UP + LEFT),
                system.get_corner(DOWN + RIGHT),
                color=ERROR,
                stroke_width=6,
            ),
            Line(
                system.get_corner(DOWN + LEFT),
                system.get_corner(UP + RIGHT),
                color=ERROR,
                stroke_width=6,
            ),
        )
        self.beat(
            0.22, Create(cross), FadeIn(self.text("active", [3.3, -2.3, 0], AMBER))
        )

    def restore(self):
        system = self.box(4.3, 2.8, CYAN).move_to([-3.4, -0.1, 0])
        lock = self.lock([-3.4, -0.1, 0])
        own = self.box(4.3, 2.8, GREEN).move_to([-3.4, -0.1, 0])
        pen = self.pencil([-3.4, -0.1, 0])
        name = self.text("customized", [-3.4, 2.2, 0], INK, 6.5)
        delete = self.button("delete", [3.5, 2.2, 0], ERROR)
        self.beat(
            0.2,
            FadeIn(system),
            FadeIn(lock),
            FadeIn(own),
            FadeIn(pen),
            FadeIn(name),
            FadeIn(delete),
        )
        restored = self.text("system_default", [-3.4, 2.2, 0], INK, 6.5)
        self.beat(
            0.26,
            FadeOut(own, shift=UP * 0.5),
            FadeOut(pen),
            self.focus(delete, color=ERROR),
            ReplacementTransform(name, restored),
        )
        duplicate = self.button("duplicate", [3.5, 2.2, 0], CYAN)
        separate = self.box(4.3, 2.8, CYAN).move_to([3.5, -0.1, 0])
        self.beat(0.15, ReplacementTransform(delete, duplicate))
        self.beat(
            0.31,
            TransformFromCopy(system, separate),
            FadeIn(self.pencil([3.5, -0.1, 0])),
            FadeIn(self.text("copy", [3.5, -2.3, 0], INK, 6.5)),
            self.focus(lock),
        )

    def deletion(self):
        rule = VGroup(
            self.box(3.1, 2.2).move_to([-4.3, -0.2, 0]),
            self.text("rule_name", [-4.3, 2.3, 0], width=6),
        )
        rule_icon = VGroup(
            Circle(radius=0.25, color=CYAN).move_to([-4.3, 0.2, 0]),
            Line([-5.2, -0.6, 0], [-3.4, -0.6, 0], color=CYAN, stroke_width=5),
        )
        target = VGroup(self.form([3.7, -0.2, 0]), self.text("layouts", [3.7, -2.3, 0]))
        link = self.arrow([-2.6, -0.2, 0], [2, -0.2, 0])
        delete = self.button("delete", [3.7, 2.3, 0], ERROR)
        blocked = self.lock([5.7, 2.3, 0])
        self.beat(
            0.24,
            FadeIn(rule),
            FadeIn(rule_icon),
            FadeIn(target),
            Create(link),
            FadeIn(delete),
            FadeIn(blocked),
        )
        self.beat(0.22, self.focus(link, color=ERROR), self.focus(blocked))
        self.beat(0.22, FadeOut(link), FadeOut(blocked))
        self.beat(
            0.26,
            self.focus(delete, color=ERROR),
            FadeOut(target, shift=DOWN * 0.5),
            FadeIn(self.mark([3.7, -0.2, 0])),
        )

    def construct(self):
        self.locale = os.environ["VIDEO_LOCALE"]
        self.content = json.loads(
            (ROOT / f"content/layouts/locales/{self.locale}.json").read_text()
        )
        timing = json.loads(Path(os.environ["VIDEO_TIMING"]).read_text())
        logo = (
            ImageMobject(str(ROOT / "cache/brand/logo_white.png"))
            .set(width=2.1)
            .move_to([-5.9, 3.65, 0])
        )
        self.add(logo)
        if self.content["english_audio_badge"]:
            self.add(
                label(
                    self.content["english_audio_badge"], self.locale, AMBER, size=44
                ).move_to([4.9, 3.8, 0])
            )
        track = Line([-6.9, -3.65, 0], [6.9, -3.65, 0], color=BORDER, stroke_width=3)
        self.add(track)
        progress = Line(
            [-6.9, -3.65, 0], [-6.89, -3.65, 0], color=GREEN, stroke_width=5
        )
        self.add(progress)
        self.chrome = list(self.mobjects)
        for index, (segment, plan) in enumerate(zip(self.content["segments"], timing)):
            self.next_section(segment["id"])
            start = self.time
            self.body_frames = plan["frames"] - 18
            self.camera.frame.save_state()
            self.wait(0.3)
            getattr(self, segment["scene_id"])()
            remaining = plan["frames"] / 30 - (self.time - start) - 0.3
            if remaining < -0.04:
                raise ValueError(f"Animation exceeds measured segment: {segment['id']}")
            if remaining > 0:
                self.wait(round(remaining * 30) / 30)
            elements = [m for m in self.mobjects if m not in self.chrome]
            self.play(
                *[FadeOut(m) for m in elements],
                self.camera.frame.animate.restore(),
                run_time=0.3,
            )
            progress.put_start_and_end_on(
                [-6.9, -3.65, 0], [-6.9 + 13.8 * (index + 1) / len(timing), -3.65, 0]
            )
