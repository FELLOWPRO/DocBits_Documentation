"""Sub-Organizations teaching film: seven synthetic UI demonstrations.

UI labels are frozen from Tolgee; notes are teaching annotations, not controls.
Names are synthetic. No live organization data is used.

The offline diagram is the fallback carrier for the picture: the shipped variant
uses an external recording of the real page (Option A), which this scene does not
replace. It follows the same layout contract as the layouts/users scenes so the
timing plan and captions derived from the script stay identical either way:
content band y = +3.0 .. -3.2 (logo above, progress bar below), x = -7.2 .. 7.2.
"""

import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from manim import (
    ImageMobject,
    VGroup,
    Circle,
    Arc,
    Line,
    Dot,
    FadeIn,
    FadeOut,
    LaggedStart,
    UP,
    DOWN,
    LEFT,
    RIGHT,
    config,
)
from brand import BORDER, INK, CYAN, GREEN, AMBER, ERROR, MUTED
from scenes.common import label
from scenes.layouts import Layouts

config.frame_width = 16
config.frame_height = 9
config.pixel_width = 1280
config.pixel_height = 720
config.frame_rate = 30
config.renderer = "cairo"

# Synthetic sub-organization names and fictional people (same style as the users scene).
NAMES = ["Demo Company", "Northwind Ltd", "Contoso GmbH"]
PEOPLE = ["Alex Example", "Alice Sample", "Bob Test"]


class SubOrganizations(Layouts):
    """Reuse the layouts primitives (box, arrow, focus, beat, toggle)."""

    # ---- primitives -------------------------------------------------------
    def quick(self, fraction, *animations):
        """Phase change: a 0.3 s fade, then hold. Never leaves a long blank frame."""
        frames = max(1, round(self.body_frames * fraction))
        motion = min(9, frames)
        self.play(*animations, run_time=motion / 30)
        if frames > motion:
            self.wait((frames - motion) / 30)

    def t(self, key, point=(0, 0, 0), color=INK, width=13.4, size=52):
        value = self.content["labels"].get(key, self.content["notes"].get(key, key))
        return label(value, self.locale, color=color, max_width=width, size=size).move_to(
            point
        )

    def btn(self, key, point=(0, 0, 0), color=CYAN, size=46, min_width=2.8, max_width=6.4):
        title = self.t(key, (0, 0, 0), INK, max_width, size)
        frame = self.box(max(min_width, title.width + 0.8), 1.0, color)
        return VGroup(frame, title).move_to(point)

    def switch(self, point, on=False):
        edge = GREEN if on else MUTED
        knob = Dot([0.4 if on else -0.4, 0, 0], radius=0.26, color=edge)
        return VGroup(self.box(1.5, 0.7, edge), knob).move_to(point)

    def avatar(self, point, color=CYAN, scale=1.0):
        ring = Circle(radius=0.4, color=color, stroke_width=4)
        head = Circle(radius=0.14, color=color, stroke_width=4).shift(UP * 0.1)
        body = Arc(radius=0.26, start_angle=0.2, angle=2.7, color=color, stroke_width=4)
        body.shift(DOWN * 0.2)
        return VGroup(ring, head, body).scale(scale).move_to(point)

    def row(self, point, text, width=13.2, color=BORDER, icon=None):
        frame = self.box(width, 1.0, color).move_to(point)
        lead = icon.move_to([point[0] - width / 2 + 0.75, point[1], 0]) if icon else None
        title = label(text, self.locale, INK, width - 2.2, 48)
        title.set_x(point[0] + (0.9 if lead else 0.0))
        title.set_y(point[1])
        return VGroup(*([frame, lead, title] if lead else [frame, title]))

    def field(self, key, point, width=9.6, color=BORDER):
        frame = self.box(width, 1.0, color).move_to(point)
        text = self.t(key, point, INK, width - 1.6, 46)
        text.align_to(frame, LEFT).shift(RIGHT * 0.4)
        text.set_y(point[1])
        return VGroup(frame, text)

    def table_head(self, keys, point=(0, 0, 0), width=13.2, color=BORDER):
        frame = self.box(width, 1.0, color).move_to(point)
        cells = []
        n = len(keys)
        for i, key in enumerate(keys):
            cell = self.t(key, (0, 0, 0), MUTED, width / n - 0.6, 40)
            cell.move_to([point[0] - width / 2 + width * (i + 0.5) / n, point[1], 0])
            cells.append(cell)
        return VGroup(frame, *cells)

    def note(self, key, point, color=AMBER):
        return self.t(key, point, color, 9.0, 40)

    # ---- 1. scope ---------------------------------------------------------
    def scope(self):
        title = self.t("sub_organizations", [0, 2.7, 0], INK, 12.0, 54)
        head = self.table_head(["name", "DESCRIPTION"], [0, 1.6, 0])
        rows = VGroup(
            *[self.row([0, 0.55 - i * 1.0, 0], n) for i, n in enumerate(NAMES)]
        )
        self.quick(0.10, FadeIn(title))
        self.quick(0.20, LaggedStart(FadeIn(head), *[FadeIn(r) for r in rows], lag_ratio=0.2))
        search = self.btn("search_suborganization", [-3.4, -2.5, 0], CYAN, 40, 5.6, 5.6)
        new = self.btn("new", [3.6, -2.5, 0], CYAN, 44, 2.4)
        self.quick(0.36, FadeIn(search, new, shift=UP * 0.2))
        tog = self.switch([-3.6, 2.6, 0], on=False)
        self.quick(0.54, FadeIn(tog), self.focus(tog))
        self.quick(0.72, FadeIn(self.note("parent_org", [-3.6, 3.35, 0])))
        self.quick(0.87, self.focus(new))

    # ---- 2. create --------------------------------------------------------
    def create(self):
        head = self.t("create_sub_org", [0, 2.7, 0], INK, 12.0, 50)
        name = self.field("field_name", [0, 1.4, 0])
        desc = self.field("description", [0, 0.1, 0])
        self.quick(0.12, FadeIn(head))
        self.quick(0.28, FadeIn(name), self.focus(name))
        self.quick(0.44, FadeIn(desc))
        hint = self.note("requires_name", [0, -0.9, 0])
        self.quick(0.58, FadeIn(hint))
        cancel = self.btn("cancel", [-2.0, -2.4, 0], MUTED, 42, 3.4)
        save = self.btn("save", [2.2, -2.4, 0], GREEN, 42, 3.0)
        self.quick(0.74, FadeIn(cancel, save))
        self.quick(0.86, self.focus(save))

    # ---- 3. search --------------------------------------------------------
    def search(self):
        box = self.field("search_suborganization", [0, 2.7, 0], width=10.4)
        typed = label("Demo", self.locale, CYAN, 4.4, 46).move_to([-2.0, 2.7, 0])
        head = self.table_head(["name", "DESCRIPTION"], [0, 1.3, 0])
        rows = VGroup(*[self.row([0, 0.25 - i * 1.0, 0], n) for i, n in enumerate(NAMES)])
        self.quick(0.14, FadeIn(box))
        self.quick(0.32, FadeIn(typed), self.focus(typed))
        self.quick(0.50, FadeIn(head))
        self.quick(0.66, FadeIn(rows[0]), self.focus(rows[0]))
        self.quick(0.84, FadeIn(self.note("created", [0, -2.7, 0])))

    # ---- 4. manage users --------------------------------------------------
    def manage_users(self):
        head = self.t("users", [0, 2.7, 0], INK, 10.0, 52)
        table = self.table_head(["name"], [0, 1.5, 0])
        rows = VGroup(
            *[
                self.row([0, 0.5 - i * 1.0, 0], p, icon=self.avatar([0, 0, 0]))
                for i, p in enumerate(PEOPLE)
            ]
        )
        add = self.btn("add_user", [-2.6, -1.9, 0], CYAN, 44, 3.8)
        ret = self.t("remove_from_other_sub_orgs", [2.4, -1.9, 0], MUTED, 6.0, 34)
        self.quick(0.14, FadeIn(head))
        self.quick(0.30, LaggedStart(FadeIn(table), FadeIn(rows), lag_ratio=0.3))
        self.quick(0.52, FadeIn(add), self.focus(add))
        self.quick(0.74, FadeIn(ret, shift=UP * 0.2))
        self.quick(0.88, FadeIn(self.note("permanent", [0, -3.05, 0])))

    # ---- 5. cross org -----------------------------------------------------
    def cross_org(self):
        title = self.t("select_all_sub_orgs_setting", [0, 2.6, 0], INK, 12.4, 48)
        off = self.switch([0, 1.0, 0], on=False)
        on = self.switch([0, 1.0, 0], on=True)
        self.quick(0.14, FadeIn(title))
        self.quick(0.30, FadeIn(off), self.focus(off))
        self.play(off.animate.become(on), run_time=9 / 30)  # switch on
        parent = self.row([0, -0.9, 0], self.PARENT)
        self.quick(0.50, FadeIn(parent), self.focus(parent))
        self.quick(0.70, self.focus(on))
        self.quick(0.86, FadeIn(self.note("parent_org", [0, -2.6, 0])))

    @property
    def PARENT(self):
        return (
            self.content["labels"].get("sub_organization")
            or self.content["notes"].get("parent_org")
            or "Organization"
        )

    # ---- 6. edit ----------------------------------------------------------
    def edit(self):
        head = self.t("edit_sub_organization", [0, 2.7, 0], INK, 12.0, 48)
        name = self.field("field_name", [0, 1.4, 0])
        desc = self.field("description", [0, 0.1, 0])
        changed = label("Northwind Group", self.locale, CYAN, 8.0, 46).move_to([0.6, 1.4, 0])
        self.quick(0.12, FadeIn(head))
        self.quick(0.28, FadeIn(name, desc))
        self.quick(0.48, FadeIn(changed), self.focus(changed))
        cancel = self.btn("cancel", [-2.0, -2.4, 0], MUTED, 42, 3.4)
        save = self.btn("save", [2.2, -2.4, 0], GREEN, 42, 3.0)
        self.quick(0.66, FadeIn(cancel, save))
        self.quick(0.82, self.focus(save))

    # ---- 7. delete --------------------------------------------------------
    def delete(self):
        head = self.t("sub_organizations", [0, 2.7, 0], INK, 12.0, 52)
        rows = VGroup(*[self.row([0, 0.9 - i * 1.0, 0], n) for i, n in enumerate(NAMES)])
        self.quick(0.14, FadeIn(head))
        self.quick(0.32, LaggedStart(*[FadeIn(r) for r in rows], lag_ratio=0.3))
        self.quick(0.52, self.focus(rows[2]))
        card = self.box(8.6, 3.0, ERROR).move_to([0, -1.4, 0])
        warn = self.t("msg_delete", [0, -1.4, 0], INK, 8.0, 38)
        self.quick(0.66, FadeIn(card), FadeIn(warn))
        cancel = self.btn("cancel", [-2.0, -2.4, 0], MUTED, 38, 3.0)
        dele = self.btn("delete", [2.2, -2.4, 0], ERROR, 38, 3.0)
        self.quick(0.82, FadeIn(cancel, dele))

    # ---- driver -----------------------------------------------------------
    def construct(self):
        self.locale = os.environ["VIDEO_LOCALE"]
        self.content = json.loads(
            (ROOT / f"content/sub_organizations/locales/{self.locale}.json").read_text()
        )
        timing = json.loads(Path(os.environ["VIDEO_TIMING"]).read_text())
        logo = (
            ImageMobject(str(ROOT / "cache/brand/logo_white.png"))
            .set(width=2.1)
            .move_to([-5.9, 3.65, 0])
        )
        self.add(logo)
        if self.content["english_audio_badge"]:
            self.add(
                label(
                    self.content["english_audio_badge"], self.locale, AMBER, size=44
                ).move_to([4.9, 3.8, 0])
            )
        track = Line([-6.9, -3.65, 0], [6.9, -3.65, 0], color=BORDER, stroke_width=3)
        self.add(track)
        progress = Line(
            [-6.9, -3.65, 0], [-6.89, -3.65, 0], color=GREEN, stroke_width=5
        )
        self.add(progress)
        self.chrome = list(self.mobjects)
        for index, (segment, plan) in enumerate(zip(self.content["segments"], timing)):
            self.next_section(segment["id"])
            start = self.time
            self.body_frames = plan["frames"] - 18
            self.camera.frame.save_state()
            self.wait(0.3)
            getattr(self, segment["scene_id"])()
            remaining = plan["frames"] / 30 - (self.time - start) - 0.3
            if remaining < -0.04:
                raise ValueError(f"Animation exceeds measured segment: {segment['id']}")
            if remaining > 0:
                self.wait(round(remaining * 30) / 30)
            elements = [m for m in self.mobjects if m not in self.chrome]
            self.play(
                *[FadeOut(m) for m in elements],
                self.camera.frame.animate.restore(),
                run_time=0.3,
            )
            progress.put_start_and_end_on(
                [-6.9, -3.65, 0], [-6.9 + 13.8 * (index + 1) / len(timing), -3.65, 0]
            )
