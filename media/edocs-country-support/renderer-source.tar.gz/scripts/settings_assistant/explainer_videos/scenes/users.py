"""Users teaching film: seven synthetic UI/decision demonstrations for Settings > Users.

UI labels are frozen from Tolgee; notes are teaching annotations, not controls.
Names are synthetic. No live organization data is used.

Layout contract: the content band is y = +3.0 .. -3.2 (logo above, progress bar
below), x = -7.2 .. 7.2. Scenes fill that band; nothing relies on a mid-scene
blank frame, and rows/boxes never overlap while moving.
"""

import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from manim import (
    ImageMobject,
    VGroup,
    Circle,
    Arc,
    Line,
    Polygon,
    Dot,
    FadeIn,
    FadeOut,
    Create,
    Transform,
    ReplacementTransform,
    LaggedStart,
    UP,
    DOWN,
    LEFT,
    RIGHT,
    config,
)
from brand import BORDER, INK, CYAN, GREEN, AMBER, ERROR, MUTED
from scenes.common import label
from scenes.layouts import Layouts

config.frame_width = 16
config.frame_height = 9
config.pixel_width = 1280
config.pixel_height = 720
config.frame_rate = 30
config.renderer = "cairo"

NAMES = ["Alex Example", "Alice Sample", "Bob Test", "Carol Demo"]


class Users(Layouts):
    """Reuse the layouts primitives (box, arrow, focus, beat, mark, toggle)."""

    # ---- primitives -------------------------------------------------------
    def quick(self, fraction, *animations):
        """Phase change: a 0.3 s fade, then hold. Never leaves a long blank frame."""
        frames = max(1, round(self.body_frames * fraction))
        motion = min(9, frames)
        self.play(*animations, run_time=motion / 30)
        if frames > motion:
            self.wait((frames - motion) / 30)

    def t(self, key, point=(0, 0, 0), color=INK, width=13.4, size=52):
        value = self.content["labels"].get(key, self.content["notes"].get(key, key))
        return label(
            value, self.locale, color=color, max_width=width, size=size
        ).move_to(point)

    def btn(self, key, point=(0, 0, 0), color=CYAN, size=48, min_width=2.8):
        title = self.t(key, (0, 0, 0), INK, 9, size)
        frame = self.box(max(min_width, title.width + 0.8), 1.0, color)
        return VGroup(frame, title).move_to(point)

    def avatar(self, point, color=CYAN, scale=1.0):
        ring = Circle(radius=0.4, color=color, stroke_width=4)
        head = Circle(radius=0.14, color=color, stroke_width=4).shift(UP * 0.1)
        body = Arc(radius=0.26, start_angle=0.2, angle=2.7, color=color, stroke_width=4)
        body.shift(DOWN * 0.2)
        return VGroup(ring, head, body).scale(scale).move_to(point)

    def row(self, point, name, width=13.2, color=BORDER):
        frame = self.box(width, 1.0, color).move_to(point)
        icon = self.avatar([point[0] - width / 2 + 0.75, point[1], 0])
        title = self.t(name, point, INK, width - 2.2, 48)
        title.align_to(icon, LEFT).shift(RIGHT * 1.0)
        title.set_y(point[1])
        return VGroup(frame, icon, title)

    def checkbox(self, point, on=False, color=CYAN, disabled=False):
        edge = MUTED if disabled else color
        parts = [self.box(0.7, 0.7, edge)]
        if on:
            parts.append(
                VGroup(
                    Line([-0.18, 0.0, 0], [-0.04, -0.15, 0]),
                    Line([-0.04, -0.15, 0], [0.22, 0.18, 0]),
                ).set_stroke(edge, 7)
            )
        return VGroup(*parts).move_to(point)

    def switch(self, point, on=False):
        edge = GREEN if on else MUTED
        knob = Dot([0.4 if on else -0.4, 0, 0], radius=0.26, color=edge)
        return VGroup(self.box(1.5, 0.7, edge), knob).move_to(point)

    def padlock(self, point, color=AMBER):
        return self.lock([0, 0, 0]).scale(1.3).set_color(color).move_to(point)

    def field(self, key, point, width=9.6, color=BORDER, dots=False):
        frame = self.box(width, 1.0, color).move_to(point)
        text = self.t(key, point, INK, width - 1.6, 46)
        text.align_to(frame, LEFT).shift(RIGHT * 0.4)
        text.set_y(point[1])
        parts = [frame, text]
        if dots:
            parts.append(
                VGroup(
                    *[
                        Dot(
                            [point[0] + width / 2 - 3.2 + i * 0.36, point[1], 0],
                            radius=0.09,
                            color=INK,
                        )
                        for i in range(7)
                    ]
                )
            )
        return VGroup(*parts)

    def star(self, point, color=AMBER):
        return self.t("*", point, color, 1, 72)

    def menu(self, point=(0, 0, 0)):
        edit = self.btn("edit", [0, 0.7, 0], CYAN, 52, 3.6)
        delete = self.btn("delete", [0, -0.7, 0], ERROR, 52, 3.6)
        card = self.box(5.0, 3.4, BORDER).move_to([0, 0, 0])
        return VGroup(card, edit, delete).move_to(point)

    # ---- 1. scope ---------------------------------------------------------
    def scope(self):
        title = self.t("users", [-1.6, 2.4, 0], CYAN, 6, 64)
        shield = self.padlock([-3.8, 2.4, 0])
        chip = self.btn("is_admin", [2.4, 2.4, 0], AMBER, 52, 3.2)
        rows = VGroup(
            *[
                self.row([0, y, 0], name)
                for name, y in zip(NAMES, [0.9, -0.3, -1.5, -2.7])
            ]
        )
        self.beat(
            0.2,
            FadeIn(title),
            FadeIn(shield),
            FadeIn(chip),
            LaggedStart(*[FadeIn(r) for r in rows], lag_ratio=0.2),
        )
        self.beat(0.12, self.focus(chip, AMBER))
        self.beat(0.05, FadeOut(title), FadeOut(shield), FadeOut(chip))
        search = VGroup(
            self.box(4.2, 1.0, CYAN), self.t("search", (0, 0, 0), INK, 3.4, 46)
        )
        analytics = self.btn("login_analytics", (0, 0, 0), CYAN, 44)
        add = self.btn("add_user", (0, 0, 0), GREEN, 44)
        toolbar = VGroup(search, analytics, add).arrange(RIGHT, buff=0.5)
        assert toolbar.width <= 14.4, toolbar.width
        toolbar.move_to([0, 2.4, 0])
        self.beat(0.08, FadeIn(toolbar))
        self.beat(0.1, self.focus(search, CYAN))
        self.beat(0.1, self.focus(add, GREEN))
        page = VGroup(
            self.box(5.6, 3.6, CYAN),
            Line([-1.8, -0.8, 0], [-0.8, 0.2, 0], color=CYAN, stroke_width=7),
            Line([-0.8, 0.2, 0], [0.0, -0.5, 0], color=CYAN, stroke_width=7),
            Line([0.0, -0.5, 0], [1.8, 1.0, 0], color=CYAN, stroke_width=7),
        ).move_to([0, -1.0, 0])
        self.beat(
            0.12,
            self.focus(analytics, CYAN),
            FadeOut(rows),
        )
        arrow = self.arrow([analytics.get_center()[0], 1.8, 0], [0, 0.9, 0])
        self.beat(0.18, Create(arrow), FadeIn(page))

    # ---- 2. search --------------------------------------------------------
    def search(self):
        box = self.box(8.2, 1.0, CYAN).move_to([0, 2.55, 0])
        placeholder = self.t("search", [0, 2.55, 0], INK, 6.8, 52)
        header = VGroup(
            self.t("name", [-4.6, 1.5, 0], CYAN, 4.2, 48),
            Polygon(
                [-0.22, -0.16, 0],
                [0.22, -0.16, 0],
                [0.0, 0.22, 0],
                color=CYAN,
                fill_opacity=1,
            ).move_to([-3.4, 1.5, 0]),
        )
        ys = [0.45, -0.65, -1.75, -2.85]
        rows = VGroup(*[self.row([0, y, 0], n, 13.0) for n, y in zip(NAMES, ys)])
        self.beat(
            0.2,
            FadeIn(box),
            FadeIn(placeholder),
            FadeIn(header),
            LaggedStart(*[FadeIn(r) for r in rows], lag_ratio=0.15),
        )
        typed = self.t("al", [0, 2.55, 0], CYAN, 6.8, 52)
        self.beat(0.2, Transform(placeholder, typed), self.focus(box, CYAN))
        self.beat(0.2, FadeOut(rows[2]), FadeOut(rows[3]))
        # Sort: swap the two remaining rows without letting them cross.
        self.beat(0.06, FadeOut(rows[0]), FadeOut(rows[1]))
        swapped = VGroup(
            self.row([0, ys[0], 0], NAMES[1], 13.0),
            self.row([0, ys[1], 0], NAMES[0], 13.0),
        )
        self.beat(
            0.32,
            FadeIn(swapped),
            header[1].animate.rotate(3.14159),
            self.focus(header, GREEN),
        )

    # ---- 3. create --------------------------------------------------------
    def create(self):
        card = self.box(12.4, 6.1, BORDER).move_to([0, -0.1, 0])
        title = self.t("add_user", [0, 2.35, 0], CYAN, 8, 58)
        first = self.field("first_name", [0, 1.2, 0])
        last = self.field("last_name", [0, 0.1, 0])
        mail = self.field("email", [0, -1.0, 0])
        stars = VGroup(self.star([5.4, 0.05, 0]), self.star([5.4, -1.05, 0]))
        tick = self.checkbox([-4.6, -2.15, 0])
        text = self.t("admin_user", [-2.5, -2.15, 0], INK, 4.6, 50)
        cancel = self.btn("cancel", [1.9, -2.25, 0], BORDER, 44, 2.6)
        save = self.btn("save", [4.6, -2.25, 0], GREEN, 44, 2.2)
        self.beat(0.16, FadeIn(card), FadeIn(title))
        self.beat(
            0.22,
            LaggedStart(FadeIn(first), FadeIn(last), FadeIn(mail), lag_ratio=0.3),
        )
        self.beat(0.22, FadeIn(stars), self.focus(last, AMBER), self.focus(mail, AMBER))
        self.beat(0.14, FadeIn(tick), FadeIn(text), FadeIn(cancel), FadeIn(save))
        on = self.checkbox([-4.6, -2.15, 0], True, GREEN)
        self.beat(0.2, ReplacementTransform(tick, on), self.focus(text, GREEN))

    # ---- 4. admin ---------------------------------------------------------
    def admin(self):
        xs = [0.2, 3.1, 6.1]
        heads = VGroup(
            self.t("is_admin", [xs[0], 2.55, 0], CYAN, 2.6, 44),
            self.t("is_system_admin", [xs[1], 2.55, 0], CYAN, 3.7, 44),
            self.t("active", [xs[2], 2.55, 0], CYAN, 1.7, 44),
        )
        rows = VGroup()
        admin_boxes = []
        for index, y in enumerate([1.2, 0.0, -1.2]):
            frame = self.box(14.2, 1.0, BORDER).move_to([0, y, 0])
            icon = self.avatar([-6.4, y, 0])
            name = self.t(NAMES[index], [-4.0, y, 0], INK, 4.2, 44)
            name.align_to(icon, LEFT).shift(RIGHT * 1.0)
            name.set_y(y)
            admin = self.checkbox([xs[0], y, 0], index != 1, CYAN)
            system = self.checkbox([xs[1], y, 0], False, CYAN, disabled=True)
            active = self.checkbox([xs[2], y, 0], True, CYAN, disabled=True)
            admin_boxes.append(admin)
            rows.add(VGroup(frame, icon, name, admin, system, active))
        self.beat(
            0.22,
            FadeIn(heads),
            LaggedStart(*[FadeIn(r) for r in rows], lag_ratio=0.2),
        )
        target = self.checkbox([xs[0], 0.0, 0], True, GREEN)
        saved = self.t("saved", [0, -2.85, 0], GREEN, 8.0, 54)
        self.beat(
            0.3,
            self.focus(admin_boxes[1], CYAN),
            ReplacementTransform(admin_boxes[1], target),
            FadeIn(saved),
        )
        locks = VGroup(self.padlock([xs[1], -2.3, 0]), self.padlock([xs[2], -2.3, 0]))
        readonly = self.t("read_only", [-1.4, -2.85, 0], AMBER, 6.0, 54)
        self.beat(
            0.4,
            FadeOut(saved),
            FadeIn(locks),
            FadeIn(readonly),
            self.focus(heads[1], AMBER),
            self.focus(heads[2], AMBER),
        )

    # ---- 5. edit ----------------------------------------------------------
    def edit(self):
        row = self.row([-3.4, 0.2, 0], NAMES[0], 8.6)
        page = VGroup(
            self.box(5.2, 5.4, CYAN),
            self.avatar([0, 1.5, 0], scale=1.6),
            Line([-1.9, 0.0, 0], [1.9, 0.0, 0], color=BORDER, stroke_width=8),
            Line([-1.9, -0.8, 0], [1.0, -0.8, 0], color=BORDER, stroke_width=8),
            Line([-1.9, -1.6, 0], [1.4, -1.6, 0], color=BORDER, stroke_width=8),
        ).move_to([4.6, -0.1, 0])
        arrow = self.arrow([0.9, 0.2, 0], [2.0, 0.2, 0])
        self.beat(
            0.14,
            FadeIn(row),
            FadeIn(page),
            Create(arrow),
            self.focus(row, CYAN),
        )
        self.quick(0.03, FadeOut(row), FadeOut(page), FadeOut(arrow))
        row2 = self.row([0, 2.1, 0], NAMES[0], 13.0)
        menu = self.menu([0, -0.7, 0])
        self.quick(0.09, FadeIn(row2), FadeIn(menu))
        self.beat(0.08, self.focus(menu[1], CYAN))
        self.quick(0.03, FadeOut(row2), FadeOut(menu))
        card = self.box(12.4, 6.1, BORDER).move_to([0, -0.1, 0])
        title = self.t("user_edit", [0, 2.35, 0], CYAN, 8, 58)
        mail = self.field("email", [0, 1.15, 0], color=BORDER)
        padlock = self.padlock([4.1, 1.15, 0])
        self.quick(0.12, FadeIn(card), FadeIn(title), FadeIn(mail), FadeIn(padlock))
        password = self.field("password", [0, -0.05, 0], color=CYAN, dots=True)
        self.beat(0.14, FadeIn(password), self.focus(password, CYAN))
        name = self.t("account_active", [-2.0, -1.4, 0], INK, 6.6, 50)
        switch = self.switch([4.2, -1.4, 0], True)
        cancel = self.btn("cancel", [1.6, -2.4, 0], BORDER, 44, 2.6)
        save = self.btn("save", [4.4, -2.4, 0], GREEN, 44, 2.2)
        self.beat(0.1, FadeIn(name), FadeIn(switch), FadeIn(cancel), FadeIn(save))
        off = self.switch([4.2, -1.4, 0], False)
        self.beat(0.1, ReplacementTransform(switch, off), self.focus(name, AMBER))

    # ---- 6. system --------------------------------------------------------
    def system(self):
        strip = self.box(13.6, 2.8, BORDER).move_to([0, 1.5, 0])
        xs = (-5.0, -1.9, 1.2)
        people = VGroup(*[self.avatar([x, 1.95, 0], scale=1.5) for x in xs])
        role = self.t("role_system_admin", [xs[1], 0.8, 0], AMBER, 4.4, 44)
        badge = self.star([xs[1] + 1.0, 2.25, 0])
        denied = self.mark([xs[0], 1.95, 0], yes=False)
        only = self.t("only_one", [5.1, 1.55, 0], AMBER, 3.6, 52)
        self.beat(0.2, FadeIn(strip), FadeIn(people))
        self.beat(0.2, FadeIn(badge), FadeIn(role), self.focus(people[1], AMBER))
        self.beat(
            0.2,
            FadeIn(denied),
            FadeIn(only),
            self.focus(people[0], ERROR),
        )
        outer = self.box(12.0, 2.5, GREEN).move_to([0, -1.85, 0])
        outer_label = self.t("admin_user", [-4.3, -1.05, 0], GREEN, 3.4, 48)
        inner = self.box(7.4, 1.0, AMBER).move_to([0.9, -2.2, 0])
        inner_label = self.t("role_system_admin", [0.9, -2.2, 0], INK, 6.4, 46)
        self.beat(
            0.34,
            FadeIn(outer),
            FadeIn(outer_label),
            FadeIn(inner),
            FadeIn(inner_label),
            self.focus(inner, AMBER),
        )

    # ---- 7. delete --------------------------------------------------------
    def delete(self):
        row = self.row([0, 2.1, 0], NAMES[0], 13.0)
        menu = self.menu([0, -0.7, 0])
        self.quick(0.1, FadeIn(row), FadeIn(menu))
        self.beat(0.14, self.focus(menu[2], ERROR))
        self.quick(0.03, FadeOut(row), FadeOut(menu))
        card = self.box(12.4, 6.0, BORDER).move_to([0, -0.1, 0])
        warning = Polygon(
            [-0.75, -0.55, 0],
            [0.75, -0.55, 0],
            [0.0, 0.75, 0],
            color=ERROR,
            stroke_width=8,
        ).move_to([0, 1.95, 0])
        mark = self.t("!", [0, 1.85, 0], ERROR, 1, 60)
        question = self.content["labels"]["delete_user_confirm_title"].format(
            name=NAMES[0]
        )
        title = label(
            question, self.locale, color=INK, max_width=11.0, size=56
        ).move_to([0, 0.55, 0])
        cancel = self.btn("cancel", [-3.0, -1.9, 0], BORDER, 52, 3.6)
        confirm = self.btn("delete_user", [3.0, -1.9, 0], ERROR, 52, 3.6)
        self.quick(
            0.03,
            FadeIn(card),
            FadeIn(warning),
            FadeIn(mark),
            FadeIn(title),
            FadeIn(cancel),
            FadeIn(confirm),
        )
        self.beat(0.2, self.focus(confirm, ERROR))
        # The note is spoken last ("You cannot undo this"): show it then.
        self.wait(self.body_frames * 0.26 / 30)
        note = self.t("no_undo", [0, -0.5, 0], AMBER, 9.0, 54)
        self.quick(0.08, FadeIn(note))
        self.beat(0.14, self.focus(note, AMBER))

    # ---- driver -----------------------------------------------------------
    def construct(self):
        self.locale = os.environ["VIDEO_LOCALE"]
        self.content = json.loads(
            (ROOT / f"content/users/locales/{self.locale}.json").read_text()
        )
        timing = json.loads(Path(os.environ["VIDEO_TIMING"]).read_text())
        logo = (
            ImageMobject(str(ROOT / "cache/brand/logo_white.png"))
            .set(width=2.1)
            .move_to([-5.9, 3.65, 0])
        )
        self.add(logo)
        if self.content["english_audio_badge"]:
            self.add(
                label(
                    self.content["english_audio_badge"], self.locale, AMBER, size=44
                ).move_to([4.9, 3.8, 0])
            )
        track = Line([-6.9, -3.65, 0], [6.9, -3.65, 0], color=BORDER, stroke_width=3)
        self.add(track)
        progress = Line(
            [-6.9, -3.65, 0], [-6.89, -3.65, 0], color=GREEN, stroke_width=5
        )
        self.add(progress)
        self.chrome = list(self.mobjects)
        for index, (segment, plan) in enumerate(zip(self.content["segments"], timing)):
            self.next_section(segment["id"])
            start = self.time
            self.body_frames = plan["frames"] - 18
            self.camera.frame.save_state()
            self.wait(0.3)
            getattr(self, segment["scene_id"])()
            remaining = plan["frames"] / 30 - (self.time - start) - 0.3
            if remaining < -0.04:
                raise ValueError(f"Animation exceeds measured segment: {segment['id']}")
            if remaining > 0:
                self.wait(round(remaining * 30) / 30)
            elements = [m for m in self.mobjects if m not in self.chrome]
            self.play(
                *[FadeOut(m) for m in elements],
                self.camera.frame.animate.restore(),
                run_time=0.3,
            )
            progress.put_start_and_end_on(
                [-6.9, -3.65, 0], [-6.9 + 13.8 * (index + 1) / len(timing), -3.65, 0]
            )
