"""Sample-count timing on the 30 fps grid, with native reading holds."""

import math
import re
import textwrap
import regex

FPS = 30


def graphemes(text):
    return len(regex.findall(r"\X", text))


def reading_rate(locale):
    return 9 if locale in {"ja", "zh"} else 12 if locale in {"ko", "th"} else 17


def caption_lines(text, locale):
    width = 24 if locale in {"ja", "zh"} else 42
    if "\n" in text:
        lines = text.splitlines()
        if any(graphemes(line) > width for line in lines):
            raise ValueError("Authored caption line exceeds native width")
        return lines
    if locale in {"ja", "zh"}:
        chars = regex.findall(r"\X", text)
        lines = []
        forbidden = set("ぁぃぅぇぉゃゅょっァィゥェォャュョッ、。）」")
        while chars:
            end = min(width, len(chars))
            stops = [i + 1 for i, c in enumerate(chars[:end]) if c in "。、"]
            if stops:
                end = stops[-1]
            while end < len(chars) and chars[end] in forbidden and end > 1:
                end -= 1
            lines.append("".join(chars[:end]))
            chars = chars[end:]
    else:
        lines = textwrap.wrap(
            text, width, break_long_words=False, break_on_hyphens=False
        )
    return lines


def cue_parts(text, locale):
    lines = caption_lines(text, locale)
    return ["\n".join(lines[i : i + 2]) for i in range(0, len(lines), 2)]


def plan_segment(segment, locale, samples, alignment, start_frame=0):
    text = segment["caption"]
    if re.search(r"[<>\x00-\x08\x0b-\x1f]", text) or "-->" in text:
        raise ValueError("Unsafe caption text")
    parts = cue_parts(text, locale)
    speech = samples / 48000
    reading = sum(
        graphemes(part.replace("\n", " ")) / reading_rate(locale) for part in parts
    )
    frames = math.ceil(FPS * max(speech + 0.75, reading + 0.75, 2))
    start_ms = round(start_frame * 1000 / FPS)
    end_ms = round((start_frame + frames) * 1000 / FPS)
    audio_start = start_ms + 250
    mode = (
        "translated_segment"
        if locale in {"hu", "sl", "th", "vi"}
        else "word" if alignment else "segment"
    )
    # A short semantic segment normally fits one cue. Multiple cues in voiced
    # text need actual phrase boundaries, not proportional English timestamps.
    boundaries = []
    if mode == "word" and len(parts) > 1:
        normalized = lambda s: re.sub(r"\s+", "", s)
        offset = 0
        for part in parts[:-1]:
            offset += len(normalized(part))
            joined = ""
            for word in alignment:
                joined += normalized(word["text"])
                if len(joined) >= offset:
                    boundaries.append(audio_start + word["end_ms"])
                    break
        if len(boundaries) != len(parts) - 1:
            raise ValueError("Word alignment does not cover caption phrases")
    else:
        weight = sum(graphemes(x) for x in parts)
        running = 0
        for part in parts[:-1]:
            running += graphemes(part)
            boundaries.append(
                round(audio_start + (end_ms - 500 - audio_start) * running / weight)
            )
    edges = [audio_start, *boundaries, end_ms - 500]
    # A natural phrase may be spoken faster than its caption can be read.
    # Preserve the audio and full text; use measured segment timing instead of
    # falsely claiming word alignment or speeding up/removing narration.
    weights = [graphemes(part.replace("\n", " ")) for part in parts]
    if mode == "word" and any(
        weight / max(0.001, (edges[i + 1] - edges[i]) / 1000)
        > reading_rate(locale) + 0.02
        for i, weight in enumerate(weights)
    ):
        mode = "segment"
        available = end_ms - 500 - audio_start
        edges = [audio_start]
        for i in range(len(parts) - 1):
            edges.append(
                round(audio_start + available * sum(weights[: i + 1]) / sum(weights))
            )
        edges.append(end_ms - 500)
    cues = []
    for index, part in enumerate(parts):
        if (
            graphemes(part.replace("\n", " "))
            / ((edges[index + 1] - edges[index]) / 1000)
            > reading_rate(locale) + 0.02
        ):
            raise ValueError(
                "Caption reading rate exceeded; split the authored segment"
            )
        cues.append(
            {
                "segment_id": segment["id"],
                "cue_id": f"{segment['id']}_{index+1:02d}",
                "start_ms": edges[index],
                "end_ms": edges[index + 1],
                "text": part,
            }
        )
    return {
        "segment_id": segment["id"],
        "scene_id": segment["scene_id"],
        "start_frame": start_frame,
        "frames": frames,
        "start_ms": start_ms,
        "end_ms": end_ms,
        "audio_start_ms": audio_start,
        "samples": samples,
        "alignment_mode": mode,
        "captions": cues,
    }
