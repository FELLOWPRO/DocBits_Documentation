"""Measure build identities and reject drift before spending on a render."""

import argparse
import importlib.metadata
import json
import platform
import subprocess
import sys
import urllib.request
from pathlib import Path
from cache import canonical, digest, file_hash, write_json

ROOT = Path(__file__).resolve().parent


def output(*args):
    return subprocess.check_output(args, text=True).strip()


def measure():
    return {
        "python": platform.python_version(),
        "architecture": platform.machine(),
        "manim": importlib.metadata.version("manim"),
        "ffmpeg": output("ffmpeg", "-version"),
        "ffprobe": output("ffprobe", "-version"),
        "libraries": {
            name: output("pkg-config", "--modversion", name)
            for name in ("cairo", "pango", "harfbuzz", "x264")
        },
        "os_packages_sha256": digest(
            output("dpkg-query", "-W", "-f=${Package}=${Version}\n").encode()
        ),
        "python_packages": dict(
            sorted(
                (d.metadata["Name"], d.version)
                for d in importlib.metadata.distributions()
            )
        ),
        "random_seed": 6274,
        "renderer": "cairo",
        "timezone": "UTC",
        "threads": 1,
        "requirements_sha256": file_hash(ROOT / "requirements.lock"),
    }


def verify():
    lock = json.loads((ROOT / "toolchain.lock.json").read_text())
    actual = measure()
    if actual != lock["environment"]:
        raise ValueError("Render toolchain differs from frozen environment")
    if (
        actual["python"] != "3.11.11"
        or actual["manim"] != "0.19.0"
        or not actual["ffmpeg"].startswith("ffmpeg version 7.1.1 ")
    ):
        raise ValueError("Required toolchain pins not satisfied")
    if not lock["image_id"].startswith("sha256:") or len(lock["image_id"]) != 71:
        raise ValueError("Missing immutable container identity")
    for font in json.loads((ROOT / "fonts.lock.json").read_text()):
        if file_hash(ROOT / "cache/fonts" / font["file"]) != font["sha256"]:
            raise ValueError("Font checksum mismatch")
    brand = json.loads((ROOT / "brand.lock.json").read_text())
    if file_hash(ROOT / "cache/brand" / brand["file"]) != brand["sha256"]:
        raise ValueError("Brand checksum mismatch")
    return lock


def install_fonts():
    directory = ROOT / "cache/fonts"
    directory.mkdir(parents=True, exist_ok=True)
    for font in json.loads((ROOT / "fonts.lock.json").read_text()):
        target = directory / font["file"]
        if not target.exists():
            target.write_bytes(urllib.request.urlopen(font["url"], timeout=60).read())
        if file_hash(target) != font["sha256"]:
            raise ValueError("Font checksum mismatch")
    conf = ROOT / "cache/fonts.conf"
    conf.write_text(
        f'<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "fonts.dtd"><fontconfig><dir>{directory}</dir><cachedir>{ROOT}/cache/fontconfig</cachedir></fontconfig>'
    )
    return conf


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--freeze-image")
    args = parser.parse_args()
    if args.freeze_image:
        write_json(
            ROOT / "toolchain.lock.json",
            {"image_id": args.freeze_image, "environment": measure()},
        )
    else:
        verify()
        print("TOOLCHAIN VERIFIED")
