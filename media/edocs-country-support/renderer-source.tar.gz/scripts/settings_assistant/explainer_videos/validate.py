"""Local artifact validation. Never performs network or publishing actions."""

import json
import struct
import subprocess
from pathlib import Path
from PIL import Image
from cache import file_hash
from vtt import serialize, transcript, validate_cues


def probe(path):
    return json.loads(
        subprocess.check_output(
            [
                "ffprobe",
                "-v",
                "error",
                "-show_streams",
                "-show_format",
                "-of",
                "json",
                str(path),
            ]
        )
    )


def faststart(path):
    atoms = []
    with Path(path).open("rb") as source:
        while data := source.read(8):
            if len(data) != 8:
                raise ValueError("Invalid MP4 atom")
            size, kind = struct.unpack(">I4s", data)
            header = 8
            if size == 1:
                size = struct.unpack(">Q", source.read(8))[0]
                header = 16
            if size == 0:
                break
            if size < header:
                raise ValueError("Invalid MP4 atom size")
            atoms.append(kind)
            source.seek(size - header, 1)
    if (
        b"moov" not in atoms
        or b"mdat" not in atoms
        or atoms.index(b"moov") > atoms.index(b"mdat")
    ):
        raise ValueError("MP4 is not faststart")


def validate_variant(directory, locale, timing):
    directory = Path(directory)
    mp4 = directory / f"{locale}.mp4"
    info = probe(mp4)
    video = next(s for s in info["streams"] if s["codec_type"] == "video")
    audio = next(s for s in info["streams"] if s["codec_type"] == "audio")
    expected = sum(s["frames"] for s in timing) / 30
    duration = float(info["format"]["duration"])
    if not 30 <= duration <= 120.05 or abs(duration - expected) > 0.05:
        raise ValueError("Duration budget/mismatch")
    if (
        video["codec_name"],
        video["profile"],
        video["pix_fmt"],
        video["width"],
        video["height"],
        video["r_frame_rate"],
    ) != ("h264", "Main", "yuv420p", 1280, 720, "30/1"):
        raise ValueError("Video format mismatch")
    if (
        audio["codec_name"],
        audio["profile"],
        audio["sample_rate"],
        audio["channels"],
    ) != ("aac", "LC", "48000", 2):
        raise ValueError("Audio format mismatch")
    if int(video["nb_frames"]) != sum(s["frames"] for s in timing):
        raise ValueError("Frame count mismatch")
    for extension, limit in [("mp4", 10_000_000), ("vtt", 32768), ("png", 1_000_000)]:
        if not 0 < (directory / f"{locale}.{extension}").stat().st_size <= limit:
            raise ValueError("Asset size budget")
    faststart(mp4)
    subprocess.run(
        ["ffmpeg", "-v", "error", "-xerror", "-i", str(mp4), "-f", "null", "-"],
        check=True,
        capture_output=True,
    )
    with Image.open(directory / f"{locale}.png") as image:
        image.load()
        if image.size != (1280, 720):
            raise ValueError("Poster dimensions")
    cues = [c for s in timing for c in s["captions"]]
    duration_ms = round(expected * 1000)
    validate_cues(cues, duration_ms)
    if (directory / f"{locale}.vtt").read_bytes() != serialize(
        cues, duration_ms
    ).encode():
        raise ValueError("VTT/inline mismatch")
    for s in timing:
        if any(
            c["start_ms"] < s["start_ms"] or c["end_ms"] > s["end_ms"]
            for c in s["captions"]
        ):
            raise ValueError("Cue crosses scene transition")
    measurement = subprocess.run(
        [
            "ffmpeg",
            "-hide_banner",
            "-i",
            str(mp4),
            "-af",
            "loudnorm=I=-16:TP=-1:LRA=11:print_format=json",
            "-f",
            "null",
            "-",
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    loudness = json.JSONDecoder().raw_decode(
        measurement.stderr[measurement.stderr.rfind("{") :]
    )[0]
    if abs(float(loudness["input_i"]) + 16) > 0.5 or float(loudness["input_tp"]) > -1:
        raise ValueError("Final AAC loudness or true peak exceeded")
    keyframes = json.loads(
        subprocess.check_output(
            [
                "ffprobe",
                "-v",
                "error",
                "-select_streams",
                "v:0",
                "-skip_frame",
                "nokey",
                "-show_frames",
                "-show_entries",
                "frame=best_effort_timestamp_time",
                "-of",
                "json",
                str(mp4),
            ]
        )
    )["frames"]
    key_times = [float(frame["best_effort_timestamp_time"]) for frame in keyframes]
    if (
        not key_times
        or key_times[0] != 0
        or any(b - a > 2.001 for a, b in zip(key_times, key_times[1:]))
    ):
        raise ValueError("Keyframe interval exceeded")
    return {
        "loudness_lufs": float(loudness["input_i"]),
        "true_peak_dbtp": float(loudness["input_tp"]),
        "locale": locale,
        "duration_ms": duration_ms,
        "bytes": mp4.stat().st_size,
        "sha256": file_hash(mp4),
        "frames": int(video["nb_frames"]),
        "full_decode": True,
        "faststart": True,
        "codec": "H.264 Main / AAC-LC",
        "transcript_bytes": len(transcript(cues).encode()),
    }
