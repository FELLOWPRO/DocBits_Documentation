"""Single source serialization for inline captions, VTT, and transcript."""

import re


def timestamp(ms):
    if type(ms) is not int or not 0 <= ms <= 120000:
        raise ValueError("Invalid caption time")
    return (
        f"{ms // 3600000:02}:{ms // 60000 % 60:02}:{ms // 1000 % 60:02}.{ms % 1000:03}"
    )


def validate_cues(cues, duration_ms):
    ids = set()
    previous = 0
    for cue in cues:
        if cue["cue_id"] in ids or not re.fullmatch(
            r"[a-z][a-z0-9_]{0,63}_[0-9]{2}", cue["cue_id"]
        ):
            raise ValueError("Invalid/duplicate cue ID")
        ids.add(cue["cue_id"])
        if not 0 <= previous <= cue["start_ms"] < cue["end_ms"] <= duration_ms:
            raise ValueError("Invalid/overlapping cue bounds")
        text = cue["text"]
        if (
            not text.strip()
            or len(text) > 240
            or len(text.splitlines()) > 2
            or re.search(r"[<>\x00-\x09\x0b-\x1f]", text)
            or "-->" in text
        ):
            raise ValueError("Invalid caption text")
        previous = cue["end_ms"]
    if not cues or len(cues) > 120 or len(transcript(cues).encode()) > 24576:
        raise ValueError("Caption budget exceeded")


def transcript(cues):
    return " ".join(" ".join(cue["text"].split()) for cue in cues)


def serialize(cues, duration_ms):
    validate_cues(cues, duration_ms)
    result = "WEBVTT\n\n" + "".join(
        f"{c['cue_id']}\n{timestamp(c['start_ms'])} --> {timestamp(c['end_ms'])}\n{c['text']}\n\n"
        for c in cues
    )
    if len(result.encode()) > 32768:
        raise ValueError("VTT budget exceeded")
    return result
