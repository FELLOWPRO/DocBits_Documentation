import json
import sys
from pathlib import Path
import pytest

P = Path(__file__).resolve().parents[2] / "scripts/settings_assistant/explainer_videos"
sys.path.insert(0, str(P))


@pytest.mark.parametrize("locale", ["en", "de", "ja", "hu"])
def test_content_parity_and_coverage(locale):
    script = json.loads((P / "content/layouts/script.yaml").read_text())
    content = json.loads((P / f"content/layouts/locales/{locale}.json").read_text())
    assert [s["id"] for s in content["segments"]] == script["segment_ids"]
    assert len(set(script["segment_ids"])) == len(script["segment_ids"])
    assert set(script["must_coverage"]) == {f"L{i:02d}" for i in range(1, 12)}
    assert all(
        set(ids) <= set(script["segment_ids"])
        for ids in script["must_coverage"].values()
    )
    for s in content["segments"]:
        assert s["caption"] and s["narration"]
        if locale != "ja":
            assert s["caption"] == s["narration"]
        assert s["scene_id"] == s["id"]
    labels = json.loads((P / "content/layouts/labels.yaml").read_text())
    assert set(content["labels"]) == set(labels["required"])
    assert all(content["labels"].values())

    assert bool(content["english_audio_badge"]) == (locale == "hu")
