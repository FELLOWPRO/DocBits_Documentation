import sys
from pathlib import Path

P = Path(__file__).resolve().parents[2] / "scripts/settings_assistant/explainer_videos"
sys.path.insert(0, str(P))
from manifest import revision


def test_page_revision_input_and_bytes():
    inventory = [{"locale": "en", "kind": "mp4", "sha256": "a" * 64, "bytes": 42}]
    first = revision({"page": "layouts", "audio": "a"}, inventory)
    assert first == revision({"audio": "a", "page": "layouts"}, inventory)
    assert first != revision({"page": "layouts", "audio": "b"}, inventory)
    assert (
        first[0]
        == revision({"page": "layouts", "audio": "a"}, [dict(inventory[0], bytes=43)])[
            0
        ]
    )
    assert (
        first[1]
        != revision({"page": "layouts", "audio": "a"}, [dict(inventory[0], bytes=43)])[
            1
        ]
    )


def test_inventory_order_does_not_change_revision():
    inventory = [
        {"locale": "en", "kind": "mp4", "sha256": "a" * 64, "bytes": 42},
        {"locale": "de", "kind": "vtt", "sha256": "b" * 64, "bytes": 20},
    ]
    assert revision({}, inventory) == revision({}, inventory[::-1])


def test_unrelated_page_content_does_not_enter_layout_inputs(tmp_path):
    from manifest import source_inputs

    inputs = source_inputs("layouts")
    assert all("transformation_rules" not in name for name in inputs)
    assert "content/layouts/locales/hu.json" in inputs
    assert "scenes/layouts.py" in inputs


def test_invalid_public_versions_fail_before_reading_media(tmp_path):
    import pytest
    from manifest import build_manifest

    for version in (0, -1, True, "1", 1.5, 9007199254740992):
        with pytest.raises(ValueError, match="Version"):
            build_manifest("layouts", [], tmp_path, version=version)
