import json
import shutil
import struct
import sys
import wave
from pathlib import Path
import pytest

needs_ffmpeg = pytest.mark.skipif(
    shutil.which("ffmpeg") is None, reason="ffmpeg not installed on this runner"
)

P = Path(__file__).resolve().parents[2] / "scripts/settings_assistant/explainer_videos"
sys.path.insert(0, str(P))
from mux import assemble, encode, run
from cache import file_hash
from validate import faststart, probe


def test_pcm_lead_tail_and_samples(tmp_path):
    directory = tmp_path / "sample"
    directory.mkdir()
    with wave.open(str(directory / "speech.wav"), "wb") as audio:
        audio.setparams((1, 2, 48000, 0, "NONE", "not compressed"))
        audio.writeframes(b"\x01\x00" * 48000)
    assemble(
        [{"cache_key": "sample", "frames": 60, "samples": 48000}],
        tmp_path,
        tmp_path / "joined.wav",
    )
    with wave.open(str(tmp_path / "joined.wav")) as result:
        assert result.getnframes() == 96000
        assert result.readframes(12000) == b"\0" * 24000
        assert result.readframes(48000) == b"\x01\x00" * 48000
        assert result.readframes(36000) == b"\0" * 72000


def test_faststart_negative_control(tmp_path):
    path = tmp_path / "bad.mp4"
    path.write_bytes(struct.pack(">I4s", 8, b"mdat") + struct.pack(">I4s", 8, b"moov"))
    with pytest.raises(ValueError, match="faststart"):
        faststart(path)


@needs_ffmpeg
def test_real_synthetic_encoding_reproducible(tmp_path):
    silent = tmp_path / "silent.mp4"
    audio = tmp_path / "audio.wav"
    run(
        [
            "-v",
            "error",
            "-f",
            "lavfi",
            "-i",
            "color=c=0x0A2531:s=1280x720:r=30:d=2",
            "-an",
            "-c:v",
            "libx264",
            "-threads",
            "1",
            silent,
        ]
    )
    run(
        [
            "-v",
            "error",
            "-f",
            "lavfi",
            "-i",
            "sine=frequency=440:sample_rate=48000:duration=2",
            "-ac",
            "2",
            audio,
        ]
    )
    for name in ("a", "b"):
        encode(silent, audio, tmp_path / f"{name}.mp4", 2)
    assert file_hash(tmp_path / "a.mp4") == file_hash(tmp_path / "b.mp4")
    faststart(tmp_path / "a.mp4")
    assert probe(tmp_path / "a.mp4")["streams"][0]["profile"] == "Main"


def test_size_budget_triggers_two_pass_then_rejects(tmp_path, monkeypatch):
    import mux

    calls = []
    target = tmp_path / "large.mp4"

    def fake_run(args):
        calls.append(args)
        target.write_bytes(b"0" * 10_000_001)

    monkeypatch.setattr(mux, "run", fake_run)
    with pytest.raises(ValueError, match="still exceeds"):
        mux.encode("silent.mp4", "audio.wav", target, 70)
    assert len(calls) == 3
    assert calls[1][calls[1].index("-pass") + 1] == "1"
    assert calls[2][calls[2].index("-pass") + 1] == "2"


@needs_ffmpeg
def test_measured_two_pass_loudness(tmp_path):
    from mux import normalize

    source = tmp_path / "speech.wav"
    target = tmp_path / "normalized.wav"
    run(
        [
            "-v",
            "error",
            "-f",
            "lavfi",
            "-i",
            "sine=frequency=440:sample_rate=48000:duration=4",
            source,
        ]
    )
    measured = normalize(source, target)
    assert abs(float(measured["output_i"]) + 16) < 0.5
    assert float(measured["output_tp"]) <= -2
    info = probe(target)["streams"][0]
    assert (info["sample_rate"], info["channels"]) == ("48000", 2)
