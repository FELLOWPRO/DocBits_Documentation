import json
import importlib.util
import shutil
import sys
from pathlib import Path
import pytest

needs_toolchain = pytest.mark.skipif(
    importlib.util.find_spec("manim") is None or shutil.which("ffmpeg") is None,
    reason="pinned video toolchain (manim 0.19.0, ffmpeg, fonts) is only in the render image",
)

P = Path(__file__).resolve().parents[2] / "scripts/settings_assistant/explainer_videos"
sys.path.insert(0, str(P))
from toolchain import verify


@needs_toolchain
def test_measured_toolchain():
    lock = verify()
    assert lock["environment"]["python"] == "3.11.11"
    assert lock["environment"]["manim"] == "0.19.0"
    assert len(lock["image_id"]) == 71


@needs_toolchain
def test_toolchain_tamper_rejected(monkeypatch):
    import toolchain

    real = toolchain.measure()
    monkeypatch.setattr(toolchain, "measure", lambda: dict(real, python="3.12.0"))
    with pytest.raises(ValueError, match="differs"):
        toolchain.verify()


@pytest.mark.parametrize("defect", [None, "language", "clipping", "caption", "join"])
def test_audio_self_check_rejects_bad_evidence(tmp_path, monkeypatch, defect):
    import wave
    import numpy as np
    import qa

    monkeypatch.setattr(qa, "ROOT", tmp_path)
    monkeypatch.setattr(qa, "verify_entry", lambda path: {})
    content = tmp_path / "content/layouts/locales"
    content.mkdir(parents=True)
    (content / "en.json").write_text(
        json.dumps({"segments": [{"id": "scope", "narration": "Hello"}]})
    )
    entry = tmp_path / "cache/tts/key"
    entry.mkdir(parents=True)
    (entry / "request.json").write_text(
        json.dumps(
            {
                "audio_locale": "de" if defect == "language" else "en",
                "input": {"language_code": "en", "text": "Hello"},
            }
        )
    )
    pcm = np.zeros(48000, dtype="<i2")
    if defect == "clipping":
        pcm[100] = 32767
    with wave.open(str(entry / "speech.wav"), "wb") as wav:
        wav.setparams((1, 2, 48000, 0, "NONE", "not compressed"))
        wav.writeframes(pcm.tobytes())
    decoded = np.zeros((96000, 2), dtype="<f4")
    if defect == "join":
        decoded[3000] = 0.1
    monkeypatch.setattr(qa.subprocess, "check_output", lambda args: decoded.tobytes())
    timing = [
        {
            "segment_id": "scope",
            "cache_key": "key",
            "samples": 48000,
            "audio_start_ms": 250,
            "end_ms": 2000,
            "start_frame": 0,
            "captions": [
                {"start_ms": 250, "end_ms": 1000 if defect == "caption" else 1500}
            ],
        }
    ]
    if defect:
        with pytest.raises(ValueError):
            qa.audio_check(tmp_path, "en", timing)
    else:
        result = qa.audio_check(tmp_path, "en", timing)
        assert result["segments"][0]["tail_ms"] == 750
        assert result["audio_locale"] == "en"
