import json
import os
import sys
from pathlib import Path
import pytest

pytest.importorskip(
    "manim", reason="pinned video toolchain is only in the render image"
)

P = Path(__file__).resolve().parents[2] / "scripts/settings_assistant/explainer_videos"
sys.path.insert(0, str(P))
from toolchain import install_fonts

os.environ["FONTCONFIG_FILE"] = str(install_fonts())
from scenes.common import label, check_glyphs
from scenes.layouts import Layouts
from manim import config, Text, tempconfig

config.media_dir = str(P / "out/test-media")
config.frame_width = 16
config.frame_height = 9


@pytest.mark.parametrize("locale", ["en", "de", "ja", "hu"])
def test_visual_bounds_and_glyphs(locale):
    content = json.loads((P / f"content/layouts/locales/{locale}.json").read_text())
    for text in [*content["labels"].values(), *content["notes"].values()]:
        item = label(text, locale, max_width=13.2)
        assert item.width <= 13.2
        assert item.font_size * 4 / 3 >= 54
    check_glyphs(content["english_audio_badge"], locale)


def test_glyph_negative_control():
    with pytest.raises(ValueError, match="Missing glyphs"):
        check_glyphs("\U0010ffff", "en")


@pytest.mark.parametrize("locale", ["en", "de", "ja", "hu"])
def test_every_storyboard_beat_fits_drawer_and_has_geometry(locale):
    """Exercise actual animation endpoints, not the removed three-label layout."""
    content = json.loads((P / f"content/layouts/locales/{locale}.json").read_text())
    seen = []

    class Audit(Layouts):
        def beat(self, fraction, *animations):
            super().beat(fraction, *animations)
            texts = [
                m for m in self.get_mobject_family_members() if isinstance(m, Text)
            ]
            for text in texts:
                if not text.get_fill_opacity():
                    continue
                assert text.get_left()[0] >= -7.7, text.text
                assert text.get_right()[0] <= 7.7, text.text
                assert text.get_bottom()[1] >= -3.2, text.text
                assert text.get_top()[1] <= 3.3, text.text
                assert text.font_size >= 44, text.text
            seen.append(len(self.get_mobject_family_members()))

    with tempconfig({"dry_run": True, "skip_animations": True, "progress_bar": "none"}):
        for segment in content["segments"]:
            scene = Audit()
            scene.locale = locale
            scene.content = content
            scene.chrome = []
            scene.body_frames = 180
            scene.camera.frame.save_state()
            getattr(scene, segment["scene_id"])()
            assert len(scene.get_mobject_family_members()) > 10
    assert len(seen) >= 45
