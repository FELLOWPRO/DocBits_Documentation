import sys
from pathlib import Path
import pytest

P = Path(__file__).resolve().parents[2] / "scripts/settings_assistant/explainer_videos"
sys.path.insert(0, str(P))
from timing import plan_segment, graphemes
from vtt import serialize, transcript, validate_cues


def segment(text="Short caption."):
    return {"id": "purpose", "scene_id": "purpose", "caption": text}


def test_sample_count_and_rounding():
    result = plan_segment(segment(), "en", 48001, [])
    assert result["frames"] == 60
    assert result["audio_start_ms"] == 250
    assert result["end_ms"] == 2000


def test_hungarian_native_hold():
    result = plan_segment(
        segment("A kiválasztási szabály minden dokumentumra vonatkozik."),
        "hu",
        48000,
        [],
    )
    assert result["frames"] > 60
    assert result["alignment_mode"] == "translated_segment"
    assert result["samples"] == 48000


def test_japanese_and_combining_graphemes():
    assert graphemes("o\u030b") == 1
    assert (
        plan_segment(segment("文書の種類を選んでください。"), "ja", 48000, [])["frames"]
        >= 60
    )


@pytest.mark.parametrize("text", ["<b>unsafe</b>", "arrow --> end", "bad\x00text"])
def test_unsafe_text(text):
    with pytest.raises(ValueError):
        plan_segment(segment(text), "en", 48000, [])


def test_vtt_exact_transcript_and_bounds():
    cues = plan_segment(segment(), "en", 48000, [])["captions"]
    assert (
        serialize(cues, 2000)
        == "WEBVTT\n\npurpose_01\n00:00:00.250 --> 00:00:01.500\nShort caption.\n\n"
    )
    assert transcript(cues) == "Short caption."
    with pytest.raises(ValueError):
        validate_cues(cues + cues, 2000)
    cues[0]["end_ms"] = 2001
    with pytest.raises(ValueError):
        validate_cues(cues, 2000)


def test_authored_japanese_breaks_preserve_phrases():
    import json
    from timing import caption_lines, cue_parts

    content = json.loads((P / "content/layouts/locales/ja.json").read_text())
    for item in content["segments"]:
        lines = caption_lines(item["caption"], "ja")
        assert all(
            len(part.splitlines()) <= 2 for part in cue_parts(item["caption"], "ja")
        )
        assert all(len(line) <= 24 for line in lines)
        assert all(
            not line.startswith(tuple("ぁぃぅぇぉゃゅょっァィゥェォャュョッ、。）」"))
            for line in lines
        )


def test_fast_phrase_keeps_audio_and_uses_honest_segment_captions():
    text = "A much longer caption explains a particular selection rule. Then it shows another result."
    words = [{"text": text[:70], "end_ms": 100}, {"text": text[70:], "end_ms": 5000}]
    plan = plan_segment(segment(text), "en", 240000, words)
    assert plan["alignment_mode"] == "segment"
    assert plan["samples"] == 240000
    assert plan["captions"][0]["start_ms"] == 250
    assert plan["captions"][-1]["end_ms"] >= 5250
    validate_cues(plan["captions"], plan["end_ms"])


def test_review_caption_clock_up_to_two_minutes():
    from vtt import timestamp

    assert timestamp(116633) == "00:01:56.633"
    with pytest.raises(ValueError):
        timestamp(120001)
