"""Provider tests never use credentials or make network requests."""

import io
import json
import shutil
import sys
import wave
from pathlib import Path
from unittest.mock import Mock

import pytest

needs_ffmpeg = pytest.mark.skipif(
    shutil.which("ffmpeg") is None, reason="ffmpeg not installed on this runner"
)

P = Path(__file__).resolve().parents[2] / "scripts/settings_assistant/explainer_videos"
sys.path.insert(0, str(P))
from cache import canonical, digest, write_json, verify_entry
from tts import request_spec, synthesize, normalize_alignment


def spec(locale="en", text="Hello.", voice="voice-id"):
    return request_spec(
        "layouts",
        "purpose",
        text,
        locale,
        {"resolved_voice_id": voice, "input": {"voice": voice, "timestamps": True}},
    )


def pcm():
    stream = io.BytesIO()
    with wave.open(stream, "wb") as w:
        w.setparams((1, 2, 48000, 0, "NONE", "not compressed"))
        w.writeframes(b"\0" * 96000)
    return stream.getvalue()


def test_canonical_and_invalidation():
    assert canonical({"b": 1, "a": 2}) == canonical({"a": 2, "b": 1})
    base = spec()
    assert base == spec("hu")
    assert (
        len(
            {
                digest(canonical(s))
                for s in [base, spec("de"), spec(text="Changed"), spec(voice="other")]
            }
        )
        == 4
    )


def test_offline_miss(tmp_path):
    provider = Mock()
    with pytest.raises(ValueError, match="Offline"):
        synthesize(spec(), tmp_path, provider)
    provider.call.assert_not_called()


@needs_ffmpeg
@pytest.mark.parametrize("queued", [True, False])
def test_queued_immediate_and_verified_cache(tmp_path, queued):
    provider = Mock()
    out = {
        "audio": {"url": "https://example.test/audio"},
        "timestamps": [{"text": "Hello.", "start": 0, "end": 0.8}],
    }
    provider.call.side_effect = (
        [
            {"request_id": "req-1", "output": None},
            {"status": "COMPLETED"},
            {"output": out},
        ]
        if queued
        else [{"request_id": "req-1", "output": out}]
    )
    provider.download.return_value = pcm()
    key, metadata = synthesize(spec(), tmp_path, provider, False)
    assert metadata["samples"] == 48000
    assert metadata["alignment_mode"] == "word"
    assert json.loads((tmp_path / key / "job.json").read_text()) == {
        "state": "cached",
        "request_id": "req-1",
    }
    assert synthesize(spec(), tmp_path) == (key, metadata)
    assert provider.download.call_count == 1
    (tmp_path / key / "speech.wav").write_bytes(b"corrupt")
    with pytest.raises(ValueError, match="corruption"):
        synthesize(spec(), tmp_path)


@needs_ffmpeg
def test_resume_no_submit(tmp_path):
    key = digest(canonical(spec()))
    directory = tmp_path / key
    write_json(directory / "job.json", {"state": "queued", "request_id": "prior-job"})
    write_json(directory / "request.json", spec())
    provider = Mock()
    provider.call.side_effect = [
        {"status": "COMPLETED"},
        {"output": {"audio": {"url": "https://example.test/audio"}}},
    ]
    provider.download.return_value = pcm()
    synthesize(spec(), tmp_path, provider, False)
    assert all(not c.kwargs.get("body") for c in provider.call.call_args_list)


def test_ambiguous_submit_no_retry(tmp_path):
    key = digest(canonical(spec()))
    write_json(tmp_path / key / "job.json", {"state": "submitting"})
    provider = Mock()
    with pytest.raises(RuntimeError, match="Ambiguous"):
        synthesize(spec(), tmp_path, provider, False)
    provider.call.assert_not_called()


def test_timeout_retains_request(tmp_path):
    provider = Mock()
    provider.call.return_value = {"request_id": "req-1", "output": None}
    with pytest.raises(TimeoutError):
        synthesize(spec(), tmp_path, provider, False, timeout=0)
    assert (
        json.loads(next(tmp_path.glob("*/job.json")).read_text())["request_id"]
        == "req-1"
    )


@pytest.mark.parametrize(
    "raw",
    [
        [{"text": "x", "start": 1, "end": 0.1}],
        {"word": "x"},
        [{"start": 0, "end": 1}],
        [
            {
                "characters": ["x"],
                "character_start_times_seconds": [],
                "character_end_times_seconds": [1],
            }
        ],
    ],
)
def test_bad_alignment(raw):
    with pytest.raises(ValueError):
        normalize_alignment(raw, 1000)


def test_observed_character_timestamps():
    raw = [
        {
            "characters": [" ", "H", "i", " ", "x"],
            "character_start_times_seconds": [0, 0.1, 0.2, 0.3, 0.4],
            "character_end_times_seconds": [0.1, 0.2, 0.3, 0.4, 0.5],
        }
    ]
    assert normalize_alignment(raw, 1000) == [
        {"text": "Hi", "start_ms": 100, "end_ms": 300},
        {"text": "x", "start_ms": 400, "end_ms": 500},
    ]


def test_transport_errors_do_not_expose_credentials(monkeypatch):
    import urllib.error
    import tts

    monkeypatch.setattr(
        tts.urllib.request,
        "urlopen",
        Mock(side_effect=urllib.error.URLError("secret-token")),
    )
    with pytest.raises(RuntimeError) as error:
        tts.Provider("secret-token").call(body={"input": "synthetic"})
    assert "secret-token" not in str(error.value)


def test_incomplete_cache_inventory_rejected(tmp_path):
    key = digest(canonical(spec()))
    write_json(tmp_path / key / "complete.json", {"files": {}})
    with pytest.raises(ValueError, match="Incomplete"):
        verify_entry(tmp_path / key)
