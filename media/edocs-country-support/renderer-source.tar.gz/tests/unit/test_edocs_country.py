import json
import os
import sys
from pathlib import Path

import jsonschema
import pytest

P = Path(__file__).resolve().parents[2] / 'scripts/settings_assistant/explainer_videos'
sys.path.insert(0,str(P))
from country_registry import COUNTRY_PAGES, DOCS_LOCALES
from tts import request_spec
from cache import canonical, digest


def test_shared_speech_is_reused_without_colliding_with_distinct_text():
    settings=json.loads((P/'voice_settings.json').read_text())
    a=request_spec(COUNTRY_PAGES[0],'workflow','Same narration','en',settings['en'])
    b=request_spec(COUNTRY_PAGES[1],'workflow','Same narration','en',settings['en'])
    assert a==b
    assert a!=request_spec(COUNTRY_PAGES[1],'workflow','Different narration','en',settings['en'])
    assert a!=request_spec(COUNTRY_PAGES[1],'workflow','Same narration','de',settings['de'])
    assert a!=request_spec('layouts','workflow','Same narration','en',settings['en'])
    assert a!=request_spec('edocs_country_unknown','workflow','Same narration','en',settings['en'])


def test_manifest_allowlist_rejects_unknown_pages_and_paths():
    schema=json.loads((P/'manifest.schema.json').read_text())
    names=schema['properties']['pages']['propertyNames']
    for page in COUNTRY_PAGES:
        jsonschema.validate(page,names)
        jsonschema.validate(f'settings-assistant/{page}/v1/zh.mp4',schema['$defs']['asset']['properties']['key'])
    for page in ('edocs_country_unknown','../germany','edocs_country_germany/../users'):
        with pytest.raises(jsonschema.ValidationError):
            jsonschema.validate(page,names)
        with pytest.raises(jsonschema.ValidationError):
            jsonschema.validate(f'settings-assistant/{page}/v1/en.mp4',schema['$defs']['asset']['properties']['key'])


def test_residual_correction_meets_target_on_real_pcm(tmp_path):
    from mux import run
    from country_audio import correct_residual, measure
    path=tmp_path/'voice.wav'
    run(['-v','error','-f','lavfi','-i','sine=frequency=410:duration=5','-af','volume=0.25','-ar','48000','-ac','2','-c:a','pcm_s16le',path])
    result=correct_residual(path)
    actual=measure(path)
    assert abs(float(actual['input_i'])+16)<.15
    assert float(actual['input_tp'])<=-1.5
    assert result['constant_gain_db']>0


@pytest.mark.parametrize('locale',DOCS_LOCALES)
def test_country_labels_and_diagrams_fit(locale):
    from toolchain import install_fonts
    os.environ['FONTCONFIG_FILE']=str(install_fonts())
    from manim import Text, tempconfig
    from country_scene import CountryScene
    # Exercise every country's first scene, then each shared scene and empty state.
    with tempconfig({'dry_run':True,'skip_animations':True,'progress_bar':'none'}):
        for page in COUNTRY_PAGES:
            content=json.loads((P/f'content/{page}/locales/{locale}.json').read_text())
            for key in ('formats','workflow','accept'):
                if key!='formats' and content['status']!='unconfirmed' and page!=COUNTRY_PAGES[0]:
                    continue
                scene=CountryScene()
                scene.locale=locale
                scene.content=content
                scene.chrome=[]
                getattr(scene,key)()
                for m in scene.get_mobject_family_members():
                    if isinstance(m,Text):
                        assert m.get_left()[0]>=-7.4,m.text
                        assert m.get_right()[0]<=7.4,m.text
                        assert m.get_bottom()[1]>=-3.4,m.text
                        assert m.get_top()[1]<=3.4,m.text
                        assert m.font_size>=34,m.text
