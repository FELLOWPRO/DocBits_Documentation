# Tatsächliche Routingprüfungen, 22.10.2026

cases.csv enthält vier tatsächliche ausgewählte Läufe einer eigenen inaktiven Regel auf dem eigenen synthetischen Trainingsbeleg. Die Entscheidungstabelle blieb unverändert: 0 bis einschließlich 1000 an Testbenutzer A, über 1000 bis einschließlich 100000 an Testbenutzer B, sonst Rückfall an A. Es wurden keine Aufgaben, E-Mails oder Exporte erzeugt. Die native Dokumentliste und die anschließende API-Lesung bestätigten die tatsächlichen Zuweisungen.

rules-template.json beschreibt diese Bedingungen; Benutzerreferenzen wurden durch YOUR_USER_A und YOUR_USER_B ersetzt. Dies ist eine Aufbauvorlage, kein zugesicherter nativer Tabellenimport. Wählen Sie vorhandene Benutzer Ihrer eigenen Testorganisation.

Die temporären Betragsänderungen dienten ausschließlich den Routingproben und passten zwischenzeitlich nicht zu den Summen der PDF. Es gab keine Freigabe und keinen Export. Nach den Aufnahmen wurde der Betrag wieder auf 1785 zurückgestellt; die letzte Zuweisung verbleibt beim eigenen Testadministrator. Beim ersten Schreiben wurden die NET_AMOUNT-Zeichenfolgen 1000.0 und 500.0 zu 1000.00 und 500.00 normalisiert; ihre Zahlenwerte blieben gleich. Während der vier eigentlichen Zuweisungsläufe blieben sämtliche Felder, Tabellen und Status unverändert.

Eine weitere Eingabeprobe hatte content=-1, aber den gespeicherten AMOUNT-Wert 1.00. Dafür wurde kein Routinglauf ausgeführt. Die negative Eingabe wurde daher nicht als belegter negativer Tabellentest gewertet. Kontrollieren Sie den gespeicherten value, bevor Sie einen Grenzfall zuordnen.
