"""Replace only the explicit synthetic org reference in training JSON files."""
import argparse
import json
from pathlib import Path
from uuid import UUID

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--org-id',type=UUID,required=True)
parser.add_argument('--out',type=Path,required=True)
args = parser.parse_args()
args.out.mkdir(parents=True,exist_ok=True)
root = Path(__file__).resolve().parent
for source in sorted(root.glob('*-input.json')):
    data = json.loads(source.read_text())
    assert data['org_id'] == '00000000-0000-4000-8000-000000000001'
    assert data['extracted_data']['org_id'] == data['org_id']
    data['org_id'] = data['extracted_data']['org_id'] = str(args.org_id)
    (args.out/source.name).write_text(json.dumps(data,ensure_ascii=False,indent=2))
    print(source.name)
