# Tatsächlicher Übergang A → B, 22.10.2026

Die Trainingsrechnung WF-TRAINING-PO-001 wurde durch einen normalen Statuswechsel
mit einem eigenen eng begrenzten Workflow verarbeitet. Der Workflow blieb nach
dem Ereignis wieder deaktiviert. Zwei bestehende Dev-Testkonten, keine Einladungen,
send_email=false, keine Exportkarte. Die Aufgabe A entstand zuerst; B blieb vorgemerkt.

Prüfer A erledigte seine Aufgabe in der normalen Oberfläche und klickte persönlich
Approve. Danach enthält die gespeicherte Genehmigung genau eine Entscheidung von A,
die aktuelle Zuständigkeit ist B, Aufgabe A ist done und die neue Aufgabe B open.
Der Status bleibt validated_pending_approval. Die Kontonamen von A werden in den
öffentlichen Bildern durch Ausschnittwahl ausgeschlossen, nicht durch Ersatztext.
summary.json enthält diese beobachteten Zustände und den tatsächlichen Entscheidungszeitpunkt.

Eine abschließende Entscheidung von B, Ablehnung durch A, Empfängerfehler und
Wiederholungsfall sind in diesem Nachweis noch nicht enthalten. Kein Exportbeleg.
workflow.json enthält die tatsächlich gespeicherte Trainingsvorlage; die konkreten
Testbenutzer-IDs sind bei einem Import durch eigene berechtigte Testkonten zu ersetzen.
Der Trainingsmarker WF_SEQ_STARTED verhindert eine erneute Anlage bei wiederholtem
Start mit dem ursprünglichen Zahlungshinweis. Seine tatsächliche Wiederholung ist
in diesem Archiv noch nicht abgenommen. Niemals Zahlungsbedingungen produktiver
Belege als Trainingsmarker verwenden.
