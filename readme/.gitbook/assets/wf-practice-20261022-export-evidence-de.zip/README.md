# Export-Praxisnachweis vom 22.10.2026

Vier tatsächlich ausgewählte inaktive Trainingsläufe am eigenen Dokumenttyp
WF_PRAXIS_20261022_A, eigener Rechnung WF-TRAINING-001 mit 1785.00 EUR und eigener
Webhook-Konfiguration. Keine gemeinsame INVOICE-Exportkonfiguration verändert.
Eine offene eigene Aufgabe war an das authentifizierte bestehende Testkonto
zugewiesen; send_email=false. Die zwei registrierten Belegfelder wurden zuvor aus
dem eigenen Original-PDF befüllt. Keine Validierungsflags/Ignore-Field-Validation.

blocked: ignore_pending_tasks=false; Exportkarte error/DOC_PENDING_TASKS, Status ready.
blocked-ignore: ignore_pending_tasks=true; im geprüften Dev-Stand ebenfalls dieselbe
Verweigerung. Der Schalter bewirkte hier keinen erfolgreichen Bypass.
Nach ordentlichem Erledigen der eigenen Aufgabe: success, Exportkarte erfolgreich,
Status exported. Genau ein tatsächlicher Empfang WF-EXPORT-20261022-001 mit
1785.00 EUR und HTTP200. Keine Buchung und keine Zahlung.
repeat: Derselbe ausgewählte Workflow stoppte am Status ready_for_validation,
weil das Dokument inzwischen exported war. Exportkarte nicht erreicht, kein
zusätzlicher Empfang. Das ist dieser konkrete Statusschutz, keine allgemeine
garantierte Idempotenz und kein Beweis für spätere manuelle Statusrücksetzungen.

receiver-receipt.json enthält die tatsächlichen protokollierten Empfangsdaten
ohne private Dokument-ID; body_sha256 bindet die unverändert privat gesicherten
Requestbytes. Die dargestellte Oberfläche /receipts wird aus diesem Journal
erzeugt. Die ursprüngliche Antwort lautet received=true, receipt=..., booking=false.
cases.csv enthält tatsächliche Kartenpfade/Status. Geschäftsfelder, Tabellen und
Zuständigkeit blieben während der vier Exportvergleiche unverändert.

workflow-immediate.json und workflow-ignore-open.json enthalten die tatsächlich
getesteten Kartenparameter. workflow-deferred.json ist NUR VORBEREITET; ein
finaler verzögerter Export, finished und der alternative Export sind hier nicht
als ausgeführt belegt. Vor Import eigene Typ-/Konfigurationsauswahl ersetzen;
numerische Konfigurations-ID3596 gehört nur zur eigenen Trainingsorganisation.
Die historische native Logansicht löst Typ-/Konfigurationsnamen nicht vollständig
auf; der separate aktuelle Karten-Screenshot und private gespeicherte IDs binden
die ausgewählte Konfiguration. Keine produktiven Zugangsdaten im Archiv.
