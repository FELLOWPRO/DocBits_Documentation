Feldbedingungen – vollständig synthetische Advanced-Test-Eingaben
Prüfdatum: 22.10.2026, Dev. Keine echten Dokumentaktionen.

1. workflow.json als eigenen inaktiven Advanced Workflow importieren.
2. In jedem input beide YOUR_ORG_ID durch die eigene Testorganisation ersetzen.
3. Test > Benutzerdefinierte Daten: vollständige JSON-Datei einsetzen.
4. Ausführen, einzelne Knotenausgänge mit observed-results.csv vergleichen.

Die Dokument-ID ist ausschließlich eine synthetische Custom-Data-ID. Sie verweist nicht auf den realen PDF-Trainingsbeleg. Die Rechnung WF-TRAINING-001 und alle übrigen Daten sind fiktiv.

Im Layout bleibt total_amount als AMOUNT definiert. In positive/boundary/invalid-number lautet auch fields[].type AMOUNT. Die übrigen vorhandenen Werte verwenden fields[].type STRING; value bleibt beim false-Fall boolesch und beim zero-Fall eine JSON-Zahl. So sind Feldmetadaten, Layout und tatsächlicher JSON-Wert einzeln sichtbar. Dies ist keine Behauptung, alle Fälle hätten denselben Feldtyp. Für eine eigene isolierte Typvariation beide Metadaten bewusst festlegen.

1785 erfüllt >1000, ist aber nicht leer; der Gesamttest ist deshalb nicht vollständig grün. 0 und "0" sind nicht leer. abc im AMOUNT-Vergleich liefert einen technischen Fehler. Fehlend/null/leerer Text/Leerzeichen sind im Leertest erfolgreich. Ein grüner Testknoten belegt keine echte Dokumentänderung.
