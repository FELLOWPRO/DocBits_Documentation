# PO-Praxisnachweis vom 22.10.2026

Die echte Trainingsrechnung wurde zu den eigenen Bestellungen A/B verbunden:
2 EA × 500 EUR = 1000 EUR und 1 EA × 500 EUR = 500 EUR. Der normale ausgewählte
inaktive Workflow mit v5-Vergleich war erfolgreich; Geschäftsfelder, Tabellen,
Status, Zuständigkeit und PO-Verbindungen blieben unverändert. Kein Export.

cases.csv und price-card-messages.json enthalten sechs tatsächlich ausgeführte
Advanced Tests. baseline liest den passenden Datenschnappschuss. Die weiteren
Fälle simulieren den ersten Dokumentpreis 510.00 bzw. 510.10 oder neue Zeilen-IDs
bei unverändert alten Verbindungen. Es sind keine Änderungen am echten Beleg.
Bestellpreis bleibt 500; die zweite Position bleibt 500. All/Any und umgekehrte
Prozentbasis werden einzeln geprüft. Die exakte 2-Prozent-Grenze ist eingeschlossen.
Ohne vergleichbare verbundene Zeile lautet das Kartenergebnis error.

Die drei workflow-*.json sind inaktive Trainingsvorlagen mit der konkreten
synthetischen Rechnungsnummer. Import und fachliche Empfänger-/Exportprüfung
bleiben in einer eigenen Testorganisation vorzunehmen. Diese Vorlagen enthalten
keine Aktionskarte. Vollständige private Beleg-/Layoutdaten sind nicht enthalten.
Die abweichenden Positionstoleranzen des PO-Abgleichs sind keine Parameter dieser
Workflow-Karte. Ein erfolgreicher Vergleich ist keine persönliche Genehmigung.
