# Statusänderung und Wiederholschutz – realer Dev-Nachweis

Eigene synthetische Rechnung WF-TRAINING-001, Betrag1785,00. Eigene Regel: Rechnung → genaue Nummer → Bereit zur Validierung → payment_terms leer → WF_DONE setzen → Statuserror, v3triggertrue. Keine Aufgaben, kein Export. Zahlungsbedingungen nur als zuvor leeres Trainingsmerkmal; im Betrieb ein eigenes dafür bestimmtes Feld verwenden.

Zwei normale Statusereignisse nach gezielter Aktivierung dieser einen Regel, keine manuell gestarteten Designer-Simulationen. Die Antworten wurden zunächst als asynchron ausstehend erkannt; kein Anlass wurde blind wiederholt. Die CSV enthält ausschließlich später gespeicherte konkrete Läufe. Regel nach jedem Anlass wieder inaktiv. Bereits angenommene Aufträge wurden bis zum Abschluss abgeglichen.

Erster Lauf alle6Knoten erfolgreich; zweiter Lauf3erfolgreiche Bedingungen, Leerprüfungfailed_condition und beideAktionen nicht ausgeführt. Andere Geschäftsfelder, Tabellen und Zuständigkeit vor/nach gleich. Anschließend Originalfeldleerwert wiederhergestellt; Belegready_for_validation.

Nicht geprüft: gleichzeitige Aufrufe, Aufgaben/Exporte, weitere Statusvarianten. Der von der ersten Statuskarte angeforderte automatische Fehler-Folgelauf ist kein Nachweis einer weiteren Ausführung dieser eigenen Regel, weil sie bereits wieder inaktiv war. Keine Behauptung einer atomaren Sperre.

Organisation, Nutzerkennungen, Dokument-UUIDs, interne Links, Zugangsdaten und Rohbelegantworten sind absichtlich nicht enthalten.
