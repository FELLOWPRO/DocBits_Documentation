"""Verify saved Advanced test responses against independent expectations."""
import json
from pathlib import Path

root = Path(__file__).resolve().parent
expected = json.loads((root/'expectations.json').read_text())
for name, want in expected.items():
    result = json.loads((root/(name+'-result.json')).read_text())
    assert result['success'] is True, (name,'test service did not execute')
    assert result['workflow_result'] == want['workflow_result'], (name,'overall result')
    nodes = result['node_results']
    assert nodes['invoice']['executed'] is True, (name,'entry')
    if want.get('no_actions'):
        assert nodes['training_invoice']['path_taken'] == want['guard_path'], (name,'scope guard')
        assert not nodes.get('amount',{}).get('executed'), (name,'amount should not execute')
        assert not any(nodes.get(n,{}).get('executed') for n in ('review','standard','data_error','complete')), (name,'unexpected action')
        print(name+': PASS')
        continue
    assert nodes['amount']['path_taken'] == want['amount_path'], (name,'condition path')
    assert nodes[want['route_node']]['executed'] is True, (name,'route not reached')
    for other in {'review','standard','data_error'} - {want['route_node']}:
        assert not nodes.get(other,{}).get('executed'), (name,'unexpected route',other)
    for terminal in ('join','complete'):
        assert nodes[terminal]['executed'] is True, (name,terminal)
        assert nodes[terminal]['path_taken'] == 'success', (name,terminal)
    messages = [m for node in result['logs'] for m in node.get('logs',[])]
    assert any(m.get('data',{}).get('new_text') == want['route_text'] for m in messages), (name,'route value')
    assert any(m.get('data',{}).get('status_to') == want['status'] for m in messages), (name,'status')
    assert any(m.get('data',{}).get('new_text') == 'YES' for m in messages), (name,'completion')
    print(name+': PASS')
print(str(len(expected))+' cases verified. Document actions in these responses were simulated.')
